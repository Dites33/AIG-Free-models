These are repaints for my freeware AI Beech 99 for FSX by Todd Bolgrin.

I have repaints completed for Freight Runners in current 2022 scheme

 I have included TGA formatted files (2048 x 2048) for details, with and without shadowing.
 Textures in DDS DXT5 format (1024 x 1024) are included. Repaints include
N109CZ
N199CZ
N299CZ
N399CZ
N499CZ
N599CZ
N699CZ
N899CZ
N999CZ

Not all of these planes had current flights, and N799CZ is missing from the list
because it hadn't flown recently, and I am not sure if it is still flying in it's old
scheme, or if it may be getting painted to match the rest of the fleet.

Install DDS files as normal and include the following in your CFG file. If you wish, you
can use the included TGA files to increase the size to 2048 x 2048, and reformat if your
computer can handle the larger size.

[fltsim.x]
title=TBAI_Beech99_N109CZ
sim=TBAI_Beech99
model=CP
texture=N109CZ
atc_id=N109CZ
atc_airline=FREIGHT RUNNERS
atc_parking_codes=FRG
atc_parking_types=CARGO, RAMP
ui_manufacturer="Beechcraft"
ui_type="C99"
ui_variation="N109CZ Freight Runners"
Description= Repaint for TBAI Beech 99 Cargo Pod Model by Todd Bolgrin

[fltsim.x+1]
title=TBAI_Beech99_N199CZ
sim=TBAI_Beech99
model=CP
texture=N199CZ
atc_id=N199CZ
atc_airline=FREIGHT RUNNERS
atc_parking_codes=FRG
atc_parking_types=CARGO, RAMP
ui_manufacturer="Beechcraft"
ui_type="C99"
ui_variation="N199CZ Freight Runners"
Description= Repaint for TBAI Beech 99 Cargo Pod Model by Todd Bolgrin


[fltsim.x+2]
title=TBAI_Beech99_N299CZ
sim=TBAI_Beech99
model=CP
texture=N299CZ
atc_id=N299CZ
atc_airline=FREIGHT RUNNERS
atc_parking_codes=FRG
atc_parking_types=CARGO, RAMP
ui_manufacturer="Beechcraft"
ui_type="C99"
ui_variation="N299CZ Freight Runners"
Description= Repaint for TBAI Beech 99 Cargo Pod Model by Todd Bolgrin


[fltsim.x+3]
title=TBAI_Beech99_N399CZ
sim=TBAI_Beech99
model=CP
texture=N399CZ
atc_id=N399CZ
atc_airline=FREIGHT RUNNERS
atc_parking_codes=FRG
atc_parking_types=CARGO, RAMP
ui_manufacturer="Beechcraft"
ui_type="C99"
ui_variation="N399CZ Freight Runners"
Description= Repaint for TBAI Beech 99 Cargo Pod Model by Todd Bolgrin


[fltsim.x+4]
title=TBAI_Beech99_N499CZ
sim=TBAI_Beech99
model=CP
texture=N499CZ
atc_id=N499CZ
atc_airline=FREIGHT RUNNERS
atc_parking_codes=FRG
atc_parking_types=CARGO, RAMP
ui_manufacturer="Beechcraft"
ui_type="C99"
ui_variation="N499CZ Freight Runners"
Description= Repaint for TBAI Beech 99 Cargo Pod Model by Todd Bolgrin


[fltsim.x+5]
title=TBAI_Beech99_N599CZ
sim=TBAI_Beech99
model=CP
texture=N599CZ
atc_id=N599CZ
atc_airline=FREIGHT RUNNERS
atc_parking_codes=FRG
atc_parking_types=CARGO, RAMP
ui_manufacturer="Beechcraft"
ui_type="C99"
ui_variation="N599CZ Freight Runners"
Description= Repaint for TBAI Beech 99 Cargo Pod Model by Todd Bolgrin


[fltsim.x+6]
title=TBAI_Beech99_N699CZ
sim=TBAI_Beech99
model=CP
texture=N699CZ
atc_id=N699CZ
atc_airline=FREIGHT RUNNERS
atc_parking_codes=FRG
atc_parking_types=CARGO, RAMP
ui_manufacturer="Beechcraft"
ui_type="C99"
ui_variation="N699CZ Freight Runners"
Description= Repaint for TBAI Beech 99 Cargo Pod Model by Todd Bolgrin


[fltsim.x+7]
title=TBAI_Beech99_N899CZ
sim=TBAI_Beech99
model=CP
texture=N899CZ
atc_id=N899CZ
atc_airline=FREIGHT RUNNERS
atc_parking_codes=FRG
atc_parking_types=CARGO, RAMP
ui_manufacturer="Beechcraft"
ui_type="C99"
ui_variation="N899CZ Freight Runners"
Description= Repaint for TBAI Beech 99 Cargo Pod Model by Todd Bolgrin


[fltsim.x+8]
title=TBAI_Beech99_N999CZ
sim=TBAI_Beech99
model=CP
texture=N999CZ
atc_id=N999CZ
atc_airline=FREIGHT RUNNERS
atc_parking_codes=FRG
atc_parking_types=CARGO, RAMP
ui_manufacturer="Beechcraft"
ui_type="C99"
ui_variation="N999CZ Freight Runners"
Description= Repaint for TBAI Beech 99 Cargo Pod Model by Todd Bolgrin



Copyright belongs to:
Todd Bolgrin
Email: tabolgrin@msn.com
For more, follow me on Alpha India Group forums
