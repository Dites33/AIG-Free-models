ASL Airlines Belgium Boeing 737-800BCF Winglets repaint for the FAIB Boeing 737-800 Winglets FSX base model.

PLEASE NOTE: THIS IS A FSX / P3D PAINT. 

These are only textures. The FAIB Boeing 737-800 Winglets FSX base model is required. It can be found at http://FSXaibureau.com/manufacturing/.  


I have tried to make the repaint as close to the real aircraft as possible, using pictures on various sites on the internet.
To install the textures, copy the "texture.ASL Airlines Belgium" folder into your FAIB Boeing 737-800 Winglets model FSX base model folder

Then open your aircraft.cfg and add the [fltsim.x] sections from the "fltsim.txt".
Remember to change the X into the consecutive number.

This is for AI traffic ONLY. The model are not supposed to be used as a user-flown aircraft.

All Rights and Copyrights of this Paint by the original author (Dennis Lyng Desezar) and may not be distributed anywhere else. This file must NOT be used in any payware or freeware package without my WRITTEN permission!
Which means you can NOT make your own package and publish this package anywhere,since the repaint are copyrighted to me as the author.

Repaint by Dennis Lyng Desezar, dldesezar@youmail.dk

====
EULA
====
Copyright Dennis Lyng Desezar Copyright © 2021 All Rights Reserved.

Model and Paintkit Copyright © 2021 FAIB Erez Weber 

IMPORTANT:
This agreement is the end-user license agreement (EULA) between you and JCAI Repaints.
This EULA is between you and JCAI repaints and governs your use of this repaint.
This EULA grants you the license to install and use this repaint for your personal use only.

Installation and use of this repaint indicates your acceptance of the terms listed here:

1: This file and everything contained in it may not be sold, rented, sublicensed, copied, modified, edited or redistributed without my express written consent.

2: If you ask for consent and receive no reply that means permission is NOT granted.

3: This AI aircraft may not be used either directly or indirectly by any program or service that charges a fee of any kind.

4: Use of this aircraft in any AI package or installer is forbidden. Use is granted only to AIG's AI Manager/One Click Installer or any other program created or managed by Alpha India Group (AIG).

This agreement is effective from the date you install this repaint.




























