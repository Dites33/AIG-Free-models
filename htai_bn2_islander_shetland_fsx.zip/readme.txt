Shetland Government BN2 Islander  (Operated by DirectFlight ltd)
Regs: G-SICA and G-SICB

Textures only. HTAI (Henry Tomkiewicz) Britten-Norman BN2 Islander base (longnose) model required.

These textures are in .DDS format for FSX

Add the folder Texture.shetland (including sub folders) to your BN2 Islander folder.

Add the following to your aircraft .cfg replacing xx with the next consecutive number

[fltsim.xx]
title=AI Britten-Norman Shetland G-SICA
sim=Britten-Norman BN-2
model=longnose
panel=
sound=
texture=shetland/SICA
kb_checklists=
ui_manufacturer=Britten-Norman
ui_type=BN-2
ui_variation=Shetland.gov opb directflight G-SICA
atc_heavy=0
atc_id=G-SICA
atc_airline=WATCHDOG
atc_flight_number=
atc_parking_codes=DCT
atc_parking_types=GATE,RAMP
description=AI Britten-Norman BN-2 Islander by Henry Tomkiewicz

[fltsim.xx+1]
title=AI Britten-Norman Shetland G-SICB
sim=Britten-Norman BN-2
model=longnose
panel=
sound=
texture=shetland/SICB
kb_checklists=
ui_manufacturer=Britten-Norman
ui_type=BN-2
ui_variation=Shetland.gov opb directflight G-SICB
atc_heavy=0
atc_id=G-SICB
atc_airline=WATCHDOG
atc_flight_number=
atc_parking_codes=DCT
atc_parking_types=GATE,RAMP
description=AI Britten-Norman BN-2 Islander by Henry Tomkiewicz

For AI Traffic FSX
Repaint by Symon Long
March 2010
cattz@longsite.co.uk
www.longsite.co.uk


