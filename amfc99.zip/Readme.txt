FSX/P3D HTAI Beech C99 Ameriflight
Textures only for HTAI Beech C99. Model and paint kit by HTAI. Converted model from FS9 to FSX native and P3D by AIG team.
Tested with P3D-V4 night and day. Included registrations for real traffic. Paint by Joel Branchu. May 2019
joelbr@orange.fr

Installation:
- Get the model at AIG website.
- Add and renumber the [fltsim.0] in your aircraft.cfg


[fltsim.0]
title=HTAIBeech C99 Ameriflight
sim=Beech_C99
model=cp_FSX // or cpp3dv4
panel=
sound=
texture=AMF
kb_checklists=
ui_manufacturer=Beechcraft
ui_type=Beech C99
ui_variation=Air North
atc_heavy=0
atc_id=N4199C,N52RP
atc_airline=AMFLIGHT
atc_flight_number=
atc_parking_codes=AMF
atc_parking_types=RAMP
description=AI Beech C99 by Henry Tomkiewicz:: Paint by Joel Branchu
visual_damage=0










