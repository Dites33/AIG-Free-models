Aerolineas Sosa Saab 340 
Reg: N366PX

Textures only. TFS (The Fruit Stand) Saab340 base  model required.

Add the folder Texture.sosa to your TFS SB340 folder.

NOTE: To use the 32 bit texture, copy the file from the folder 'texture.sosa_32-bit' to the folder 'texture.sosa'
and overwrite.

Add the following to your aircraft .cfg replacing xx with the next consecutive number

[fltsim.xx]
title=TFS Saab 340 Aerolineas Sosa
sim=TFS_Saab_340
model=
sound=
texture=sosa
atc_airline=
ui_manufacturer=The Fruit Stand
ui_type=Saab 340
ui_variation=Saab 340 Aerolineas Sosa
description=The Fruit Stand Saab 340 
atc_parking_codes=
atc_parking_types=GATE

For AI Traffic
Repaint by Symon Long
September 2010
cattz@longsite.co.uk
www.longsite.co.uk


