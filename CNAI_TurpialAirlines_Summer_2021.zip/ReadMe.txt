Thank you for downloading this CNAI flightplan package.

*******************************************************************************

DETAILS:

AUTHORED BY:	Carlos Augusto Narvaez Diaz
EMAIL:		ca1972nd@hotmail.com
WEEK:		17th - 23rd May 2021

NOTES:		20 weekly flights, 2 aircraft


		
*******************************************************************************

IMPORTANT LEGAL NOTICE:

This package, and its contents, can not be redistributed in any way without the 
author's explicit and written permission.

********************************************************************************

INSTALLATION INSTRUCTIONS:

Flightplans can be installed with AIG's AI Manager, AIFP v3 or manually with
AIG Traffic Tools (AIGTT).

For fastest installation we recommend AIG's AI Manager using One-Click-Installer (OCI)
Available at: https://www.alpha-india.net/forums/index.php?topic=24614


Since we provide accurate cruise speeds for the Flightplans you can leave the 
'Always Use Aircraft.cfg Cruise Speed' in AIFPv3's Options menu unticked.
 
If you want to install the FlightPlans manually, unzip the archive. 
Then go to the Aircraft.txt and change the speed values to 200 (or leave it as is, 
if the speed is already below 200). Save the file and compile the Aircraft, 
Airport, and Flightplan files with AIGTT.

*******************************************************************************
