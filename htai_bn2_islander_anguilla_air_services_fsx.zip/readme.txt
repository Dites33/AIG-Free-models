Anguilla Air Services  BN2 Islander 
Reg: VP-AAS, VP-AAC

Textures only. HTAI (Henry Tomkiewicz) Britten-Norman BN2 Islander base model required 
Textures are in DDS format for FSX

Add the folder Texture.AAS (including sub folders) to your BN2 Islander folder.

Add the following to your aircraft .cfg replacing xx with the next consecutive number

[fltsim.xx]
title=AI Britten-Norman BN-2 Anguilla VP-AAS
sim=Britten-Norman BN-2
model=longnose
panel=
sound=
texture=AAS/VP-AAS
kb_checklists=
ui_manufacturer=Britten-Norman
ui_type=BN-2
ui_variation=Anguilla Air Services VP-AAS
atc_heavy=0
atc_id=VP-AAS
atc_airline=
atc_flight_number=
atc_parking_codes=
atc_parking_types=GATE,RAMP
description=AI Britten-Norman BN-2 Islander by Henry Tomkiewicz


[fltsim.xx+1]
title=AI Britten-Norman BN-2 Anguilla VP-AAC
sim=Britten-Norman BN-2
model=shortnose
panel=
sound=
texture=AAS/VP-AAC
kb_checklists=
ui_manufacturer=Britten-Norman
ui_type=BN-2
ui_variation=Anguilla Air Services VP-AAC (op. by Trans Anguilla Air)
atc_heavy=0
atc_id=VP-AAC
atc_airline=
atc_flight_number=
atc_parking_codes=
atc_parking_types=GATE,RAMP
description=AI Britten-Norman BN-2 Islander by Henry Tomkiewicz

For AI Traffic(FSX)
Repaint by Symon Long
February 2009
cattz@longsite.co.uk
www.longsite.co.uk


