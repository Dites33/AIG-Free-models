Learjet 31 AI package. 24 repaints and AI flight plans, model and master textures by Henry Tomkiewicz.

The flight plans are optimized for compilation with "AI Flight Planner" by Don Grovestine. If you still use TTools you have to set the aircraft speed to "200" and ad the "@" sign to the flight plans.

Thank you for downloading and have fun.

Ralf Maylin
r.maylin@hotmail.de