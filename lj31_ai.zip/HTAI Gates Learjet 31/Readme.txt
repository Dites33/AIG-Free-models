***************************************
Gates Learjet 31
AI Model for FS2002 & FS2004 ATC
by Henry Tomkiewicz, November 2004
***************************************

This model was built with FSDS version 2.24, primarily for use as an AI model in FS2002 and FS2004's ATC traffic. It's simple, low polygon design make it ideal for AI traffic use.

Credits:
Thanks to Dee Waldron for his FSDS technical support, unlimited patience, and for getting me started in FS modeling. 

General Notes:
This model is currently in development and I'll make more updates to it as I get reports from people who use it.
The textures are basic masters, 256 color (8-bit), 1024x1024 bitmap. Chrome reflections, and lightmap for night lighting are activated. User is welcome to repaint the model in any livery(s) desired. Uploads of repainted models are also welcome. No prior permission is required.
Flight dynamics are based on the default Lear Jet, so it will work well as an AI model, but will not operate realistically as a Gates Learjet 31.
If anyone makes any improvements to the flight model which lets the AI model fly more realistically as a Gates Learjet 31, please send me a copy and I'll include it in a future update.

*****************************************************************************

Installation
Unzip the archive directly into your flight simulator's Aircraft folder. It will automatically be setup as a regular, flyable model. To include the model in your ATC traffic, you need to use utilities such as Lee Swordy's "Traffic Tools". This is a freeware utility available at most major flight sim websites.

*****************************************************************************

Legal Stuff:
Copyright 2004, Henry Tomkiewicz. All rights reserved.
This aircraft model is freeware. All repaints, enhancements or modifications are welcome, but must remain free. No exceptions. User accepts all risk of use.

Henry Tomkiewicz
ht@retroai.net
 