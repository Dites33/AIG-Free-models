Thank you for downloading this AIG flightplan package.

*******************************************************************************

DETAILS:

AUTHORED BY: 	Florian Wilmer
TESTED BY:	Ryan Carson & Martin Panz
RELEASED BY: 	AIG Alpha-India Group
EMAIL: 		Florian-Wilmer@t-online.de
SUPPORT: 	www.alpha-india.net/forums
WEEK:		16th - 22nd July 2018


NOTES:		Almost all "regular" flights of this week included plus some more
		that I could fit in. A few flights had to be dropped, to fit in
		some other flights.
		Due to their tight schedule some departure/arrival times had to
		be adjusted slightly to get a proper schedule.

		Most of the flights were operated under own callsign/tripnumber.
		But they also operate some flights for CSA.

		Due to FS-limition I chose that they're only flying under 
		TVS-flightnumbers and their regular "SKYTRAVEL"-callsign.

		Fleet info:
		 2x Boeing B737-900ER
		 4x Boeing B737-8MAX
		22x Boeing B737-800WL (1x opb Mongolian Airlines, 2x opb Swiftair)
		 2x Boeing B737-700
		 1x Boeing B737-400 (opb YanAir)

		Further aircraft are operating for their other subsidaries in Poland,
		Slovakia and Hungary.
		
		
		
*******************************************************************************
IMPORTANT NOTE:

We would very much like to thank the Alpha-India Team for the effort put in to 
producing and beta testing each flightplan.  Thanks guys!

Our goal is to provide accurate flightplans in order to populate Microsoft 
Flight Simulator with real world traffic throughout the world. These 
flightplans are based on many sources and are the best that we have been 
able to compile. They are accurate to the extent that our data and the 
limitations of the Flight Simulator AI engine allow.

*******************************************************************************

IMPORTANT LEGAL NOTICE:

This package, and its contents, can not be redistributed in any way without the 
author's explicit and written permission.

********************************************************************************

INSTALLATION INSTRUCTIONS:
 
FlightPlans can be installed with AI Flight Planner v3 (AIFPv3) or manually with 
TTools.
 
For fastest installation we recommend AIFPv3 by Don Grovestine, which you can 
download at http://stuff4fs.com (http://stuff4fs.com/newpage.asp?JS=True&Folder=AIFP).

More information in our forums: 

	http://www.alpha-india.net/forums/index.php?topic=9594.0

Since we provide accurate cruise speeds for the Flightplans you can leave the 
'Always Use Aircraft.cfg Cruise Speed' in AIFPv3's Options menu unticked.
 
If you want to install the FlightPlans manually, unzip the archive. 
Then go to the Aircraft.txt and change the speed values to 200 (or leave it as is, 
if the speed is already below 200). Save the file and compile the Aircraft, 
Airport, and Flightplan files with TTools.

*******************************************************************************

SPECIAL THANKS:

All the beta-testers at AIG. Without them we would not have been able to release 
this flightplan.

*******************************************************************************