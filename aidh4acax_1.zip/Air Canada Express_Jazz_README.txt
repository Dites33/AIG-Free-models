Dash 8-400 Air Canada Express 'Jazz'.

Model by Craig Ritchie
Base Paint by Boris Le Veve, John Massey and Craig Ritchie
FS2004 FDE by Steve Tran
Paint By: Boris Le Veve (borisintaipei                  @                                gmail.com)

*****************
TURN ON WORD WRAP
*****************

******
IMPORTANT NOTICE:

YOU DEFINITELY HAVE NO PERMISSION TO USE THIS REPAINT AS BASIS FOR ANY PAINTING EXPERIMENTS!!!!

THESE FILES MAY ONLY BE UPLOADED TO AVSIM or FLIGHTSIM.COM BY THE ORIGINAL AUTHOR/S.

THESE FILES SHOULD NOT BE UPLOADED TO http://www.fs2000.org.
Questi file non deve essere caricate http://www.fs2000.org.
DO NOT UPLOAD THESE FILES TO http://www.fs2000.org.
Non caricare questi file http://www.fs2000.org.

THESE FILES MAY ONLY BE UPLOADED TO AVSIM or FLIGHTSIM.COM BY THE ORIGINAL AUTHOR/S.

THESE FILES MAY NOT BE UPLOADED TO ANY OTHER SITE WITHOUT THE AUTHOR'S WRITTEN PERMISSION. THESE REPAINTS ARE FREEWARE AND MAY NOT BE SOLD, OR PUT ON ANY SITE THAT CHARGES FOR DOWNLOADING FREE FILES. THE FILES FOUND IN THIS ARCHIVE MAY NOT BE DISTRIBUTED ON CD OR ANY MEDIUM FOR ANY KIND OF FEE, INCLUDING THE COST OF PRODUCTION, MATERIALS OR POSTAGE.

Specifically, you DO NOT HAVE PERMISSION to place this file on a DVD or CD and then sell it on Ebay or anywhere else.


>>>>>>>>READ THIS!!!!<<<<<<<<<<<<

NOT RECEIVING A ANSWER FROM A PERMISSION REQUEST DOES NOT!!!! MEAN PERMISSION WILL BE AUTOMATICALLY GRANTED!!!!!

******
INSTALLATION:

1) Just drop the "texture.Air Canada Express_Jazz" folder into your "TFS_Dash_8_400" folder. (The base package (tfsdh4.zip) must be downloaded separately to use this paint).
2) Copy the [fltsim.x] entry supplied into the aircraft.cfg file supplied in the base package mentioned above. Be sure to number them correctly, starting sequentially with [fltsim.0] and working your way up with each additional livery you add...e.g. [fltsim.0], [fltsim.1], [fltsim.2]...making sure not to skip or duplicate any numbers in the sequence.
3) Then assign the aircraft to some flightplans and you're on your way.

For more information or If you're not sure how to assign an aircraft to a flightplan, please visit our website at http://www.the-fruit-stand.com and look in the FAQ / Help section of our forums. Be sure to post any problems you may have or bugs you may find in our forum.


*** IMPORTANT!!! ****
Not affiliated with, or endorsed by this Airline or Bombardier Aerospace. Not for commercial sale.

THIS AIRCRAFT IS FREEWARE.

*** IMPORTANT!!! ****
THIS MODEL (*.MDL) MAY NOT BE DECOMPILED AND EDITED/MODIFIED IN ANY WAY WITHOUT THE EXPRESS PERMISSION OF THE DESIGNER!!!

*** VISIT THE ROTTEN FRUIT STAND WEBSITE! http://www.the-fruit-stand.com ***

REQUEST MORE BEFORE THE SUMMER COMES!

Craig Ritchie
Tony Fosler
Federico Permutti
Denis Schranz
Jakob Tischler
Heiko Schmidt
Boris Le Veve
Walter Zimmermann
Jaime Correa
Arnaud Solvay
John Massey
David Freed
Robert Smith
David Rawlins
Boback Shahsafdari
Phillip Tan
Chris Reuter
Steve Tran
Jonathan Barton
Ralf Winkler

**Independent Guest Painter**
----->NOW WORKING FOR GEE WHIZ<-------


January, 2009


Comments or suggestions:

comments@the-fruit-stand.com