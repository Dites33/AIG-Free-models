[fltsim.x]
title=FAIB Airbus A320S NEO Azul Linhas Aereas Daisy Duck PR-YSK FSX
sim=FAIB_A320
model=CFML_S
texture=Azul Daisy Duck PR-YSK
atc_airline=AZUL
ui_manufacturer=Azul Linhas Aereas
ui_type=A320-200neo
ui_variation=Azul Linhas Aereas
ui_createdby=FAIB
description=FAIB A320 Azul Linhas Aereas Daisy Duck PR-YSK -- Repaint by Kamil Fryzol.
atc_parking_codes=AZU
atc_parking_types=GATE
-----------------------------------------------------------------------------------------------------
4.Replace X is by an increasing number according to the number of liveries installed on your aircraft.cfg. Each  [fltsim.x] record must be UNIQUE, example: [fltsim.15],[fltsim.16] etc.

Kamil Fryzol
fryzol1a@gmail.com
MAR,2023
****************************************************************************************************************************
Enjoy your flight!





