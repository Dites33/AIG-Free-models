Repaint of the The Fruit Stand Boeing 777-200ER in Nordwind Airlines color. Base files package for FS2004 (tfs772.zip) available at avsim.com. This is an AI only aircraft.

Denis Petrov

diesel1722@rambler.ru