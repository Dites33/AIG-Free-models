///TURN ON WORD WRAP!///
///FSX VERSION!///


This is one of Felix's Crummy Repaints! Next one should be more from Corendon, but don't count on it.

This pack contains a repaint for FAIB's FSX 737-800W model, in Corendon Airlines's colours, registration TC-TJH. The FS9 version is also available on Avsim.

Installation:
You will need to have the normal winglet model installed, which is available from www.fsxaibureau.com. Navigate to the folder, and copy the following section into the 'aircraft.cfg' file in it (and remember to change the xx to the next number in the sequence!):

[fltsim.xx]
title=FAIB 737-800W Corendon Airlines
sim=FAIB_7378
model=winglets
texture=Corendon Airlines
atc_airline=CORENDON
ui_manufacturer=FAIB
ui_type=Boeing 737-800W
ui_variation=Corendon Airlines
description=F
atc_parking_codes=CAI
atc_parking_types=GATE

Then copy the texture folder from the zip archive to the aircraft's folder. It is 'texture.Corendon Airlines'.

Then assign the plane to some flightplans, and visit sunny Turkey! I recommend Jeroen Eekhof's plans, available now at flyingcarpet75.com.

Thanks:
Thanks to FAIB for the model and paintkit, and big thanks to Kyle Meek for beta testing!

Please note:
Not affiliated in any way with Corendon Airlines, Boeing, or anyone else for that matter.

Legal:
No-one is allowed to upload these files anywhere without my permission, nor distribute them through any other means such as CD/DVD/USB Drive, paid for, for costs of distribution, or for free.  If you want to use these textures in anything, then please e-mail me and I'll think about it, but I'm not guaranteeing anything! It is also illegal to edit these textures in any way without my permission, so don't.

Thanks!
Felix Chapman

f.j.h.chapman@gmail.com (in case of problems!)