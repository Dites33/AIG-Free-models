Aer Arann Islands  ( Part of Aer Arran)  BN2 Islander 
Reg: EI-CUW  (longnose) and EI-AYN (shortnose)

Textures only. HTAI (Henry Tomkiewicz) Britten-Norman BN2 Islander base model required.
These textures are in DDS format for FSX

Add the folder Texture.REA ( including sub folders) to your BN2 Islander folder.

Add the following to your aircraft .cfg replacing xx with the next consecutive number

[fltsim.xx]
title=AI Britten-Norman BN-2 Aer Arann Islands EI-CUW
sim=Britten-Norman BN-2
model=longnose
panel=
sound=
texture=REA/EI-CUW
kb_checklists=
ui_manufacturer=Britten-Norman
ui_type=BN-2
ui_variation=Aer Arann Islands EI-CUW
atc_heavy=0
atc_id=EI-CUW
atc_airline=AER ARANN
atc_flight_number=
atc_parking_codes=REA
atc_parking_types=GATE,RAMP
description=AI Britten-Norman BN-2 Islander by Henry Tomkiewicz

[fltsim.xx+1]
title=AI Britten-Norman BN-2 Aer Arann Islands EI-AYN
sim=Britten-Norman BN-2
model=shortnose
panel=
sound=
texture=REA/EI-AYN
kb_checklists=
ui_manufacturer=Britten-Norman
ui_type=BN-2
ui_variation=Aer Arann Islands EI-AYN
atc_heavy=0
atc_id=EI-AYN
atc_airline=AER ARANN
atc_flight_number=
atc_parking_codes=REA
atc_parking_types=GATE,RAMP
description=AI Britten-Norman BN-2 Islander by Henry Tomkiewicz

For AI Traffic (FSX)
Repaint by Symon Long
February 2009
cattz@longsite.co.uk
www.longsite.co.uk


