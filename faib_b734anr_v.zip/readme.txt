Repaints of YanAir Boeing 737-400. Two variations included:
- UR-COI (metallic patch above cockpit windows)
- UR-CQX (web titles, less windows)

For use with Normal model by FSX AI Bureau(FAIB)

From now on I will put .dds textures for FSX users, no unpacked tga's, if you need them , just drop me a mail

Credits: 
Model, Paintkit: Erez Werber
Paint: Ken Carson (nobodyxx_ad@yahoo.com)