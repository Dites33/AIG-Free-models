Bombardier Challenger 604 JBAI ACASS Canada ACAS C-FKGY

Operator: ACASS Canada
Registration: C-FKGY
ICAO: 
Callsign: 

Aircraft:
Repaint of C-FKGY for the Bombardier Challenger 604 AI model (604) by Kelly Freeman.FS9 model available at http://library.avsim.net/esearch.php?CatID=fs2004aia&DLID=121019P3Dv4 model available at http://www.alpha-india.net/forums/index.php?topic=27454.0

Flight plans:
https://oneclickhangar.com/forum/index.php



Please see separate file for aircraft.cfg configs

Legal
-----
These repaints have been downloaded from www.oneclickhangar.com
These repaints are copyright Morten Blindheim.
These repaints may not be uploaded to any other site.
If you have any comments or questions, please visit www.oneclickhangar.com or email at morten@oneclickhangar.com
Follow me on Twitter @oneclickhangar - https://twitter.com/oneclickhangar - for latest news on my FS add-ons 
