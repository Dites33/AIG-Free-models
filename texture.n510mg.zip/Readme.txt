Gulfstream G-IV  N510MG
Canal Air LLC
Repaint of Henry Tomkiewicz fabulous Gulfstream G-IV 
Real registration


[fltsim.XXX]
title=AI Gulfstream G-IV N510MG
sim=AI Gulfstream G-IV
model=
panel=
sound=
texture=N510MG
ui_manufacturer=Gulfstream
ui_type=G-IV
ui_variation=N510MG
atc_heavy=0
atc_id=
atc_airline=
atc_flight_number=200
editable=0
atc_id_color=0000000000
visual_damage=0
description="AI Gulfstream G-IV by Henry Tomkiewicz" repaint by JRC 
atc_parking_codes=
atc_parking_types=RAMP


JR CADENE