AERO-SMITH, INC. BEECHCRAFT KING AIR B200 - N404DP Repaint - FSX/P3D

This repaint is for the HTAI Beechcraft King Air B200 Door model by Henry Tomkiewicz.
This repaint represents the King Air B200 N404DP flown in charter service by Aero-Smith, Inc.
based at Martinsburg, WV. - KMRB.

HTAI Super King Air B200 AI aircraft is available at http://htai-models.com/downloads.html
FSX/P3D compatible model file is available on the A.I.Group website forum at:
 http://www.alpha-india.net/forums/index.php?topic=25048.0
   
The textures are .dds DXT5 format and have been tested in both FSX and P3D v3.4.
(FS9 textures and flight plans available separately) 

INSTALLATION:

Unzip and add the 'TEXTURE.N404DP' folder to your HTAI Beechcraft King Air B200 Door folder.  
Add the contents of the aircraft-cfg.txt file to the aircraft config file, 
renumbering the [fltsim.x] sequence as necessary .


- - - - - - - - - - - - - - - - - - - - - - - -

AI FLIGHT PLANS: Flight plans for Aero-Smith, Inc. charter service are available at:
https://aibizjetproject.weebly.com/a.html

- - - - - - - - - - - - - - - - - - - - - - - -

LEGAL STUFF ( Standard disclamers, but important to read, etc. )

These repaints are freeware. They are not to be used or included in any media,
uploaded to any website for which any type of fee (MONEY) is charged. You know, 
the usual copyright stuff.  Unless you really mess up, these by themselves will 
not harm your computer. If you like them, great! I'm open to criticism both good 
or bad, but if you don't like these textures, by all means erase them from your 
computer.
Last I checked there are at least two DEL keys on every keyboard. ;-)


"Low, slow, and squawking 1200."


'JoeCoastie' - Joe Bowers -  near KLKU
joe_air@verizon.net
  

