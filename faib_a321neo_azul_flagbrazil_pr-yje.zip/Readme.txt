[fltsim.x]
title=FAIB Airbus A321S NEO Azul Linhas Aereas Flag Brazil PR-YJE FSX
sim=FAIB_A321
model=CFML_S
texture=Azul Flag Brazil PR-YJE
atc_airline=AZUL
ui_manufacturer=Azul Linhas Aereas
ui_type=A321-200neo
ui_variation=Azul Linhas Aereas
ui_createdby=FAIB
description=Airbus A321-200neo Azul Linhas Aereas Flag Brazil PR-YJE -- Repaint by Kamil Fryzol.
atc_parking_codes=AZU
atc_parking_types=GATE
-----------------------------------------------------------------------------------------------------
4.Replace X is by an increasing number according to the number of liveries installed on your aircraft.cfg. Each  [fltsim.x] record must be UNIQUE, example: [fltsim.15],[fltsim.16] etc.

Kamil Fryzol
fryzol1a@gmail.com
APR, 2022
****************************************************************************************************************************
Enjoy your flight!





