FSX/P3D Zagros Airlines Airbus Fleet
Textures only for FAIB A319CFM, A320CFM and A321IAE.
Model and paint kit by: FAIB.
Painted by Joel Branchu for real traffic with all registrations.
Feb 2018
joelbr@orange.fr

Installation:
- Drop the texture on the appropriate folder 
- Add and renumber the fltsim.txt in your aircraft.cfg


[fltsim.txt]
title=FAIB A319 CFM Zagros Airlines
sim=FAIB_A319
model=CFM
texture=IZG
atc_airline=ZAGROS
ui_manufacturer=FAIB
atc_id=EP-ZAX
ui_type=Airbus A319
ui_variation=Zagros Airlines:: Paint by Joel Branchu
ui_createdby=FAIB
description=FAIB Airbus A319
atc_parking_codes=IZG
atc_parking_types=GATE

[fltsim.txt]
title=FAIB A320-200 CFM Zagros Airlines
sim=FAIB_A320
model=CFM
texture=IZG
atc_id=EP-ZAP,EP-ZAV,EP-ZAL,EP-ZAJ,EP-ZAU,EP-ZGC,EP-ZAT 
atc_airline=ZAGROS
ui_manufacturer=Airbus
ui_type=A320-200
ui_variation=Zagros Airlines
ui_createdby=FAIB 
description=For AI use only A320-200 CFM :: Repaint by Joel Branchu
atc_parking_codes=IZG
atc_parking_types=GATE

[fltsim.txt]
title=FAIB Airbus A321-200 IAE Zagros Airlines
sim=FAIB_A321
model=IAE
texture=IZG
atc_id=EP-ZGA,EP-ZGB
atc_airline=ZAGROS
ui_manufacturer=FAIB
ui_type=Airbus A321-200
ui_variation=Zagros Airlines
ui_createdby=FAIB 
description=For AI use only, Zagros Airlines:: Repaint Joel Branchu
atc_parking_codes=IZG
atc_parking_types=GATE




