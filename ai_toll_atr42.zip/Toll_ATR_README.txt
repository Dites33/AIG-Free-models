AI ATR-42-300QC Toll Priority
Thanks for downloading my repaint of the OSP ATR 42
Original Model:		Oskari Syynimaa (OSP)
Paint By: 		Sean Gregory (sean@seanshootsphoto.com)
*****************
TURN ON WORD WRAP
*****************

Installation....

1) Just drop the "texture.Toll VH-TOX" folder into your "osp_atr_42_300" folder. (The base package for this aircraft must be downloaded separately to use this paint).
2) Copy the [fltsim.x] entries supplied into the aircraft.cfg file supplied in the base package mentioned above. Be sure to number them correctly, starting sequentially with [fltsim.0] and working your way up with each additional livery you add...e.g. [fltsim.0], [fltsim.1], [fltsim.2]...making sure not to skip or duplicate any numbers in the sequence.
3) Then assign the aircraft to some flightplans and you're on your way.

////////////////////////////////////////////////////////////////////

Note.

This is strictly for freeware use and no uploading or redistribution of the files in any form is allowed without written permission from me.

This repaint is intended to be used with the flightplans that came with my updated Toll Metro package (ai_toll_metropack_v2.zip).
I will be releasing more repaints of the types not already covered for those flightplans. This is an ongoing project for me and I will only stop when I am satisfied with the level of AI traffic in my own game.

Feel free to contact me for any comments or queries regarding this package.

Sean Gregory
sean@seanshootsphoto.com

Happy Flying


