Andes Lineas Aereas
repaint for FAIB Boeing 737-800WL
Brazil, July, 2023
=============================================================================
For install, unzip the texture.XXX into your FAIB Boeing 737-800 folder and
ADD the lines bellow into your aircraft.cfg

[fltsim.x]
title=FAIB 737-800WL ANDES LV-KFW
sim=faib738wv6acof
model=winglets
texture=ANDES
atc_id=LV-KFW
atc_airline=Andes
ui_manufacturer=AI TRAFFIC
ui_type=B737-800WL
ui_variation=Andes LV-KFW
description=
atc_parking_codes=ANS
atc_parking_types=GATE,RAMP

Where .x is next number of last [fltsim] on your aircraft.cfg and enjoy.
Where sim= replace by your *.air file!
=============================================================================
Major artwork by Alexandre Alves

Alexandre Alves
islander_ktr@hotmail.com
=============================================================================