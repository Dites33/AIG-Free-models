FlightPlan installation instructions:
-------------------------------------------------------------------

Copy and paste: aircraft.txt, airports.txt and flightplans.txt files into your TTools.exe folder in your version of Flight Simulator numbering them to suit your needs, "save" then click to compile.

-------------------------------------------------------------------
______________________________________________________________________________________________________________________________________
Billy Rutherford
billy_rutherford@blueyonder.co.uk