MD-80 upgraded details info.
-------------------------------------------------------------------

I have upgraded all my own existing MD-8x repaints with my own 'slightly' enhanced paintkit. Anything not done has either crashed, been scrapped, stored or moved on to someone I have no interest in.

-------------------------------------------------------------------

Changes are:

New static ports:
I had to compromise with these as they should be even lower down on the fuselage, but had to keep them where they were finally positioned due to texture bleed. They looked dreadfull otherwise.

New doors/exits again!:
This is probably the 3rd or 4th time I've redone these but think they are the best representation now.

New underwing/fin panels:
I have changed these to much lighter shades at the outer panels to break the wing colour up a little as they look in reality.

New dirt:
I have yet to see a spotless MD-80, well if just out of the paintshop perhaps, but most Airlines don't seem to bother even painting them, they must be the largest amount of patchy hybrids in our skies. Yet in saying this they always seem to keep them clean above the engines? Mainly the wings and fins have been dirtied down, not too much or they looked riddiculous. I tried it both ways. I also added to the rear of the aircraft quite bit of dirt as they generally seem to be filthy around this area. I see very little with exhaust marks on the fuselage so usually disable them.

That's about it really, other than that I love this model by Aardvark, mind you it would be nice if the flaps deployed a little on take off.
Billy.
-------------------------------------------------------------------
___________________________________________________________________
___________________________________________________________________
Billy Rutherford
billy_rutherford@blueyonder.co.uk
