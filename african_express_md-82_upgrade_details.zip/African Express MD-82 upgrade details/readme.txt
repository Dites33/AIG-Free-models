African Express Airways Aardvark McDonnell Douglas MD-82 '5Y-AXN'
repaint for AI traffic including the Airline's scheduled operations taken from their website for 'Summer 09'.

-------------------------------------------------------------------

Add to cfg:

[fltsim.x]
title=AIA MD-82 African Express Airways
sim=aia_MD_8X
model=cone_no_refl
texture=African Express
atc_id=5Y-AXN
atc_airline=Express Jet
ui_manufacturer=Aardvark
ui_type=McDonnell Douglas MD-82
ui_variation=African Express Airways
description=African Express Airways - Cone tail.
atc_parking_codes=AXK
atc_parking_types=GATE

___________________________________________________________________
___________________________________________________________________
Billy Rutherford
billy_rutherford@blueyonder.co.uk
