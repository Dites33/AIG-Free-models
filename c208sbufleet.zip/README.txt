--------------------------------------------------------------------------------------------------
Repaint of ST.BARTH COMMUTER for HTAI Cessna C208B Grand Caravan

This repaint made for HTAI C208B/AIA EMB190 model, base files package are availble in

Original Model C208: http://htai-models.com/downloads.html
FSX/P3D V4 CVT C208: http://www.alpha-india.net/forums/index.php?topic=26166.0

This package includes 2 variations of this lovely small airline.

The repaints made with wonderful HD paintkit from Morten Blindheim, look your excellent site with 
many works for AI Traffic: www.oneclickhangar.com

Painted by:
Alexandre Alves, Brazil, July 2018
islander_ktr@hotmail.com

This work is entirely freeware, but in case you wish to send some donation in recognition of the 
work, feel free using the contact e-mail islander_ktr@hotmail.com on paypal.

Enjoy this project!
Alexandre Alves
Brazil, July 2018
--------------------------------------------------------------------------------------------------
1. Unzip the "texture.XXX" folders to your "HTAI C208B" folder.

2. Copy the following  section in to aircraft.cfg below existing [fltsim] sections.
Replace the XX with the next number in sequence.

[fltsim.xx]
title=C208 STBARTH COMMUTER F-OSJR
sim=AI Cessna 208B
model=cp
panel=
sound=
texture=SBU_FOSJR
kb_checklists=
ui_manufacturer=Cessna
ui_type=C208B
ui_variation="St.Barth Commuter F-OSJR"
atc_heavy=0
atc_id=F-OSJR
atc_airline=Black Fin
atc_flight_number=
atc_parking_codes=SBU
atc_parking_types=RAMP
description=AI Cessna 208B Grand Caravan by Henry Tomkiewicz repainted by Alexandre Alves

[fltsim.xx]
title=C208 STBARTH COMMUTER F-OSBH
sim=AI Cessna 208B
model=cp
panel=
sound=
texture=SBU_FOSBH
kb_checklists=
ui_manufacturer=Cessna
ui_type=C208B
ui_variation="St.Barth Commuter F-OSBH"
atc_heavy=0
atc_id=F-OSBH
atc_airline=Black Fin
atc_flight_number=
atc_parking_codes=SBU
atc_parking_types=RAMP
description=AI Cessna 208B Grand Caravan by Henry Tomkiewicz repainted by Alexandre Alves
--------------------------------------------------------------------------------------------------