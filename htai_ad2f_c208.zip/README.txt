Texture into AZUL CONECTA TWOFLEX temporary colors for HTAI C208B CARGOPOD
Repaint by Alexandre Alves with HD Paintkit by Morten Blindheim
=============================================================================
For install, unzip the texture.TWOFLEX2021 into your HTAI C208B CARGOPOD and
ADD the lines bellow into your aircraft.cfg

[fltsim.x]
title=C208 AZUL CONECTA PR-MAU
sim=AI Cessna 208B
model=cp
panel=
sound=
texture=TWOFLEX2021
ui_manufacturer=Cessna
ui_type=C208B
ui_variation="PR-MAU"
atc_heavy=0
atc_id=PR-MAU
atc_airline=TWOFLEX
atc_flight_number=
atc_parking_codes=OWT
atc_parking_types=RAMP
description=AI Cessna 208B Grand Caravan by Henry Tomkiewicz and Repainted by Alexandre Alves

After this, insert on your AI TRAFFIC with personal flightplan and enjoy.
=============================================================================
Alexandre Alves
Brazil, July, 2021
islander_ktr@hotmail.com
=============================================================================
On last November, 2020, i�ve completed 20 years of flight simulation, there
are more than 200 files on FlightSim.com and 300 files on AVSIM, from scenary
to repaints, many many flight plans, after all AI TRAFFIC is mine passion!

If you like my work and want to send a "coffee" as a thank you, feel free at
paypal islander_ktr@hotmail.com. If you are Brazilian, contact me on the same
email if you want another way.

The giving in thanks is a free attitude of those who think it is cool to do.
=============================================================================