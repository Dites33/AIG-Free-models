Thank you for downloading this repaint package.

Unum Group Hawker 800XP Fleet

These repaints are not allowed to be uploaded anywhere without the original author's consent.

If support is needed, the author can be contacted at esteinmetz83@sbcglobal.net.

These repaints were created using Morten Blindheim's One Click Repaint Plugin, available here: https://oneclickhangar.com/oneclickrepaint/index.php

To install, copy desired texture files to your HTAI HS-125-800 (Hawker 800) folder, then add the included fltsim entries to the aircraft.cfg.