Karun Airlines Fokker F100 two repaints
previously Naft Airlines
Model & paintkit AIA

muenier@gmail.com