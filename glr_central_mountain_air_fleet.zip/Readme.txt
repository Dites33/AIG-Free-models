Thank you for downloading my repaint package for Central Mountain Air's fleet, a Canadian regional airline operating scheduled and charter flights throughout British Columbia and Alberta.  More information on this airline can be found at their website (http://centralmountainair.com/) and on Wikipedia (http://en.wikipedia.org/wiki/Central_Mountain_Air).

This repaint set includes textures for three variants of their Beech 1900Ds (different tails: small mountain, large mountain, and blank), and both of their Dornier 328-100s (white & blue and white & red).  Specifics on which scheme matches which aircraft can be found in the included Fleet Info.txt.

If you're using Steve Lewis' fall 2010 flight plans (AvSim: central_mountain_air_f10.zip, FlightSim: centralmountainair.zip), these match up as follows:

B1900D Small Mountain:	AC#5,360,"HTAI B1900D CMA STD"
B1900D Large Mountain:	AC#3,360,"HTAI B1900D CMA C-FCMP"
B1900D Blank Tail:	AC#4,360,"HTAI B1900D CMA C-GGBY"
Do328-100 C-FDYN:	AC#1,290,"JBAI Do328 CMA"
Do328-100 C-FHVX:	AC#2,290,"JBAI Do328 CMA C-FHVX"

Textures are in 32-bit 888-8 and 16-bit DXT3 formats (with and without MIPmaps).

Thanks to Henry Tomkiewicz for the Beech model and paintkit; and to Juan Sebasti�n Gonz�lez Silva, Andrew Carroll, Andrew Langille, and Jannik Dahl for the Dornier model and paintkit.

Please do not distribute these files without permission.  I can be reached by e-mail at teamnutmeg (at) gmail (dot) com.

--------------------------------------------------------------

To use this package:

1) If you don't already have them, download the base files for the aircraft, available at:

HTAI Beech 1900D at HTAI: http://www.htaimodels.com/downloads.html

JBAI Dornier 328-100 at AvSim.com: http://library.avsim.net/search.php?SearchTerm=jbai_dornier328_v2.zip

Please note you should have the standard JBAI model (i.e. the folder labeled just "model") for this repaint.  The texture will work with the no_apu model if absolutely necessary.


2) Extract the model folders from their respective .zip files to your aircraft folder.  By default, the aircraft folder is located at:

FS2004:	C:\Program Files\Microsoft Games\FS2004\Aircraft
FSX:	C:\Program Files\Microsoft Games\Microsoft Flight Simulator X\SimObjects\Airplanes

(If you're running a 64-bit version of Windows, the default location will be in "Program Files (x86)" not "Program Files".)


3) Choose one of the packages: 32-bit, DXT3, or Mipped DXT3 (if in doubt, use the normal DXT3 files).  Copy the texture.RBY-Vision Airlines folder from that package folder to your new Do328 folder.

	Example: This Package\32-Bit\JBAI Dornier 328-100\texture.GLR-Central Mountain Air folder copies to SimObjects\Aircraft\JBAI_Dornier328_V2

	3a) The default Beech prop is revised for FSX; if it produces undesirable results in FS2004, you may want to copy the original prop-hs.bmp (included in the base folder of this package) to each of the B1900D folders.	


4) Open each aircraft folder's aircraft.cfg file with Notepad or Wordpad.  You should see at least 1 entry beginning with "[fltsim.xxx]" numbering upward from 0.  Go to the last of these entries (right before the "[General]" section), and take note of the number of the last entry.  Then copy-and-paste the corresponding "[fltsim]" entries from the "Add to Aircraft.cfg.txt" file in this package right after the last entry, and before the "[General]" section.


5) Change the [fltsim.x] entries to the next entry.  If you've just downloaded the model, this will probably be "1" - e.g. "[fltsim.1]".


6) Load up a flight from Smithers Airport, British Columbia and enjoy!


Chris "TeamNutmeg" Thompson
teamnutmeg (at) gmail (dot) com