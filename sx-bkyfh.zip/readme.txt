
_________________________________________

Repaint of King Air C90 SX-BKY for AI Traffic
_________________________________________

CONTENT

The greek King Air C90B SX-BKY is operated by Air Intersalonika. This file contains textures for the AI model by Henry Tomkiewicz and does not contain flightplans.

_________________________________________

INSTALLATION

First, you have to install the base model available here:

http://www.htaimodels.com/downloads.html

Now please copy the c90_l.bmp to your FS root texture folder. (I.e. ...\Flight Simulator 9\texture) Overwrite if prompted. (That would mean that the texture needed is allready in place.)

Then copy the texture folder into the directory of the aircraft. After that, add the content of the add_to_aircraft.cfg.txt to your aircraft.cfg -- don't forget to replaces the x'es in [flightsim.x] etc. with consecutive numbers following the number of the last section of your aircraft.cfg.

Done! :->
_________________________________________

CONTACT:
Email: Felix@Lexif.de
Or at the UltimateGA forum:
http://www.ultimatega.com/forum/
_________________________________________

License:
- The contents of this file are copyrighted by Henry Tomkiewicz (model and paintkit) and Felix Hippmann (repaints).
- They are NOT PUBLIC DOMAIN.
- Therefore, they may NOT be uploaded anywhere else without my permission.
- You may not use any part of the textures in other repaints because quality will suffer by recompression. If you want, you can get a copy of the uncompressed source file. Just mail me! :->
- Please ask me before including them in another package. Do not compile them into another package without permission.
- You are not permitted to make money with these files, in any form.

_________________________________________

G�ttingen, 2006
Felix Hippmann
(Felix@Lexif.de)