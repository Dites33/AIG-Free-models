Installation :

1 - Copy and past the 'texture' in your FAIB_A321S_CFM folder
2 - Copy and past the fltsim.txt in your FAIB_A321S_CFM aircraft.cfg
