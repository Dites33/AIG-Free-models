FSX/P3D HTAI B1900C Ameriflight
Textures only for HTAI B1900C. Model and paint kit by HTAI.
Converted model from FS9 to FSX native and P3D by AIG team.
Tested with P3D-V4. Included registration for real traffic. Paint by Joel Branchu. May 2019
joelbr@orange.fr

Installation:
- Get the model at AIG website.
- Add and renumber the [fltsim.0] in your aircraft.cfg


[fltsim.0]
title=HTAI B1900C Ameriflight
sim=AI Beechcraft 1900C
model=
texture=AMF
atc_id=N388AF
atc_airline=AMFLIGHT
atc_flight_number=
ui_manufacturer=HTAI
ui_type=Beechcraft 1900C
ui_variation=Ameriflight
ui_createdby=HTAI
description=AI Beechcraft 1900C by Henry Tomkiewicz, For AI use only :: Paint by Joel Branchu.
atc_parking_types=RAMP
atc_parking_codes=AMF










