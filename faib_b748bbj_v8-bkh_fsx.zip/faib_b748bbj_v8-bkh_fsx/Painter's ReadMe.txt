FAIB Boeing 747-8i BBJ V8-BKH

Repaint of the FAIB 747-8i for FSX/P3D in the colors of Brunei Government - V8-BKH.

This file does not contain any model, you must already have the model installed.


-------------
!!NOTE!!

This file may not be uploaded anywhere without the author's permission. The textures may under 
no circumstances be sold. The contents of the zip file may not be included in a package (free or not) without the author's permission.
-------------

Model Designer: FSX AI Bureau, Erez Werber
Paintkit: FSX AI Bureau, Erez Werber
Livery: Daniel Fall


Daniel Fall
danielfall@gmail.com


-----------------
Add to aircraft.cfg:

[fltsim.x]
title=FAIB 747-8i V8-BKH
sim=FAIB_7478
model=
texture=V8-BKH
atc_airline=Brunei
ui_manufacturer=FAIB
ui_type=Boeing 747-8i
ui_variation=V8-BKH
ui_createdby=FAIB
description=Boeing 747-8I - Painted by Daniel Fall
atc_heavy=0
atc_parking_codes=BBJ0
atc_parking_types=RAMP