Repaints of Twin Jet Beechraft 1900D (4 variants) for the Henry Tomkiewicz model. This is for AI use only.


INSTALLATION:

1) Just drop the texture folder (DXT or 32 bit of your choice) into the Henry Tomkiewicz Beechcraft 1900C folder. The base package must be downloaded separately (ai_beechcraft_1900d.zip at http://htai-models.com).
2) Copy the [fltsim.x] entry into the aircraft.cfg file supplied in the base package. Be sure to number them correctly, starting sequentially with [fltsim.0] and working your way up with each additional livery you add...e.g. [fltsim.0], [fltsim.1], [fltsim.2]...making sure not to skip or duplicate any numbers in the sequence.
3) Be sure when filling in your [fltsim.x] entries that you pay special attention to which model you are needing to use.
4) Then assign the aircraft to some flightplans and you're on your way.

For more information or If you're not sure how to assign an aircraft to a flightplan, please visit Alpha India Group Forum at http://www.alpha-india.net.

If you have any comments and/or suggestions, please feel free to contact me.

1965dk@naver.com
