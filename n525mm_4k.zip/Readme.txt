Cessna CitationJet CJ1 DFAI Aguilar Aviation Llc USGA N525MM

Operator: Aguilar Aviation Llc
Registration: N525MM
ICAO: 
Callsign: 

Aircraft:
Repaint of N525MM for the Cessna CitationJet M2 AI model (M2) by David Frostin.FS9 model available at https://secure.simmarket.com/dfai-developpement-cessna-citation-cj1-cj1-m2-and-tamarack-version-fs9.phtmlFSX model available at https://secure.simmarket.com/dfai-developpement-cessna-citation-cj1-cj1-m2-and-tamarack-version-fsx.phtmlP3Dv4 model available at https://secure.simmarket.com/dfai-developpement-cessna-citation-cj1-cj1-m2-and-tamarack-version-p3dv4.phtmlP3Dv5 model available at https://secure.simmarket.com/dfai-developpement-cessna-citation-cj1-cj1-m2-and-tamarack-version-p3dv5.phtml

Flight plans:
https://oneclickhangar.com/forum/index.php?topic=5713.0



Please see separate file for aircraft.cfg configs

Legal
-----
These repaints have been downloaded from www.oneclickhangar.com
These repaints are copyright Morten Blindheim.
These repaints may not be uploaded to any other site.
If you have any comments or questions, please visit www.oneclickhangar.com or email at morten@oneclickhangar.com
Follow me on Twitter @oneclickhangar - https://twitter.com/oneclickhangar - for latest news on my FS add-ons 
