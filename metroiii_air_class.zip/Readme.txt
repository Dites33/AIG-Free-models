Repaint of the Craig Ritchie - DJC Metroliner III in  Air Class colour scheme. Base files package for FS2004 (djc_met.zip) available here. This is an AI aircraft only 
All Rights of the Paint by the original author and may not be distributed anywhere else and on any medium without written permission.

Juergen Baumbusch

crashpilot1985@freenet.de

