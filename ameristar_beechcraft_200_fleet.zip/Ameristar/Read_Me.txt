Ameristar Beechcraft B200 Fleet
------------------------------------------------------------------------
Repaint of the Ameristar Beechcraft B200 Fleet (2 variations).  Textures Only.  This is an AI only aircraft.  

You will need the following model:
HTAI Beechcraft B200 available seperately at htai-models.com

IMPORTANT LEGAL NOTICE: 
All Rights of the Paint by the original author and may not be distributed anywhere else and on any medium without written permission.

Elias Merino
eliasmerino@msn.com
Colombia


---
You can find more of my repaints @ www.flyingcarpet75.com