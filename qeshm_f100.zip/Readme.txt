Thank you for downloading my repaint package for two Fokker 100s, registered as EP-FQG and EP-FQI, flown by Qeshm Air of Iran.  This airline is based out of Dayrestan Airport, aka Qeshm International Airport, on Qeshm Island.  More information on this airline can be found at their website (http://qeshm-air.com) and on Wikipedia (http://en.wikipedia.org/wiki/Qeshm_International_Airport).

For this package, you will need the following model:

AI Aardvark Fokker 100:		http://library.avsim.net/download.php?DLID=126401
				http://dfs2.flightsim.com/download.php?fn=aiafk100.zip					

These textures are available in 32-bit 888-8 and 16-bit DXT3 (with and without MIPmaps) formats.

Thanks go to David Rawlins, aka AI Aardvark, for the model and paintkit - among many, many others.

Please do not distribute these files without permission.  This especially applies to Fly Away Simulation.  I can be reached by e-mail at teamnutmeg (at) gmail (dot) com.

--------------------------------------------------------------

To use this package:

1) If you don't already have them, download the base file(s) for the model(s) from the links provided above.


2) Extract the model folder(s) from their respective .zip files to your aircraft folder.  By default, the aircraft folder is located at:

FS2004:	C:\Program Files\Microsoft Games\FS2004\Aircraft
FSX:	C:\Program Files\Microsoft Games\Microsoft Flight Simulator X\SimObjects\Airplanes

(If you're running a 64-bit version of Windows, the default location will be in "Program Files (x86)" not "Program Files".)


3) To install the textures, choose one of the packages which corresponds to your version of the sim, and then choose 32-bit, DXT3, or DXT3 with MIPs (if in doubt, use the default (DXT3 without MIPs) files).  Copy the paintscheme folders to the corresponding aircraft folder.

	Example: "This Package\texture.Qeshm EP-FQG" copies to "Aircraft\AIA_FOKKER_100"


4) Open the aircraft.cfg file with Notepad or Wordpad.  You should see at least 1 entry beginning with "[fltsim.xxx]" numbering upward from 0.  Go to the last of these entries (right before the "[General]" section), and take note of the number of the last entry.  Then copy-and-paste the corresponding "[fltsim]" entry from the "Add to Aircraft.cfg.txt" file in this package right after the last entry, and before the "[General]" section.  If you have just installed the model, you will see a note at the beginning of the file telling you where to paste this new entry.


5) Change the "x" in the [fltsim.x] line on the newly-pasted entry to the next number.  If you've just installed this model, this will be entry "0".

Enjoy!

Chris "TeamNutmeg" Thompson