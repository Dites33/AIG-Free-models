BOEING 737-200adv Private N733TW.

Readme based on TFS's readme file.
Model and Basepaint by Erez Werber
Paint By:Juergen Baumbusch (crahspilot1985@freenet.de)
*****************
TURN ON WORD WRAP
*****************

******
IMPORTANT NOTICE:


THESE FILES MAY ONLY BE UPLOADED TO AVSIM or FLIGHTSIM.COM BY THE ORIGINAL AUTHOR/S.

THESE FILES MAY NOT BE UPLOADED TO ANY OTHER SITE WITHOUT THE AUTHOR'S WRITTEN PERMISSION. THESE REPAINTS ARE FREEWARE AND MAY NOT BE SOLD, OR PUT ON ANY SITE THAT CHARGES FOR DOWNLOADING FREE FILES. THE FILES FOUND IN THIS ARCHIVE MAY NOT BE DISTRIBUTED ON CD OR ANY MEDIUM FOR ANY KIND OF FEE, INCLUDING THE COST OF PRODUCTION, MATERIALS OR POSTAGE.

Specifically, you DO NOT HAVE PERMISSION to place this file on a DVD or CD and then sell it on Ebay, Aldi, 7-Eleven, Rakuten or anywhere else.

DON'T INCLUDE THIS AIRPLANE IN COPYRIGHT INFRINGING PACKAGES SUCH AS THOSE MADE BY ADOBE, TANTRIS, ICE ETC.


>>>>>>>>READ THIS!!!!<<<<<<<<<<<<


----SPECIAL NOTE----

This is an AI aircraft and will NOT BE VISIBLE in the aircraft selection window in flight simulator. However if you want it to be visible in the aircraft selection window, you have to edit the "FAIB_7372.air" file with the program "AirEd" (available (if not corrupt) at AVSIM "aired.zip"), change "Aircraft Type" from "2" to "0".

NO SUPPORT IS GIVEN TO HUMAN PILOTS, AI PILOTS ARE FREE TO CONTACT US ABOUT HELP AND CERTIFICATION.

>>>>>>>>READ THIS!!!!<<<<<<<<<<<<

******
INSTALLATION:

1) Just drop the "texture.ARG_Retro" folder into the correct base model folder. (The base package must be downloaded separately to use this paint).
2) Copy the [fltsim.x] entries supplied into the aircraft.cfg file supplied in the base package mentioned above. Be sure to number them correctly, starting sequentially with [fltsim.0] and working your way up with each additional livery you add...e.g. [fltsim.0], [fltsim.1], [fltsim.2]...making sure not to skip or duplicate any numbers in the sequence.
3) Then assign the aircraft to some flightplans and you're on your way.

For more information or If you're not sure how to assign an aircraft to a flightplan, please visit our website at http://fsxaibureau.com and look in the FAQ / Help section of our forums. Be sure to post any problems you may have in the help section (when it becomes active).

********
NOTES

This aircraft was designed specifically for use as an AI aircraft. As such, the primary design criteria were that it look good sitting at the gate, or as seen when landing from an aircraft waiting to take off.

This aircraft feature 6 LOD'S for optimal performance, to learn more about LOD'S and why they are important go here: http://en.wikipedia.org/wiki/Level_of_detail

******

DO NOT USE SOMEONE ELSES REPAINT AS A BASIS FOR YOUR REPAINT WITHOUT FIRST OBTAINING PERMISSION FROM THE ORIGINAL PAINTER!!!
THIS INCLUDES FAIB REPAINTS.

DO NOT INCLUDE THE MODEL WITH YOUR REPAINT.

IMPORTANT
Not affiliated with, or endorsed by Private N733TW or Boeing Aircraft. Not for commercial sale.

THIS AIRCRAFT IS FREEWARE.

*** IMPORTANT!!! ****
THIS MODEL (*.MDL) MAY NOT BE DECOMPILED AND EDITED/MODIFIED IN ANY WAY WITHOUT THE EXPRESS PERMISSION OF THE DESIGNER!!!

*** VISIT THE FAIB WEBSITE! http://fsxaibureau.com ***

Sometime in 1 April, 2012


Comments or suggestions:

comments@fsxaibureau.com