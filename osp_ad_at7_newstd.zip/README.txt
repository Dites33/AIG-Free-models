Azul Brazilian Airlines
repaint for OSP ATR72
Brazil, March, 2023
=============================================================================
For install, unzip the texture.XXX into your OSP ATR72-500 folder and ADD
the lines bellow into your aircraft.cfg

[fltsim.x]
title=ATR600 AZUL AKF ROSA
sim=ospatr72-500v6acof
model=
panel=
sound=
texture=AZUL_AKF
kb_checklists=
kb_reference=
atc_id=PR-AKF
atc_airline=Azul
atc_flight_number=725
atc_parking_codes=ATR,AZU
atc_parking_types=RAMP,CARGO
ui_manufacturer=Traffic Plane
ui_type=ATR72-600
ui_variation=AZUL TKJ
description=

[fltsim.xx]
title=ATR600 AZUL AKO BANDEIRA
sim=ospatr72-500v6acof
model=
panel=
sound=
texture=AZUL_AKO
kb_checklists=
kb_reference=
atc_id=PR-AKO
atc_airline=Azul
atc_flight_number=726
atc_parking_codes=ATR,AZU
atc_parking_types=RAMP,CARGO
ui_manufacturer=Traffic Plane
ui_type=ATR72-600
ui_variation=AZUL AKO
description=

[fltsim.xxx]
title=ATR600 AZUL AKN NOMASK
sim=ospatr72-500v6acof
model=
panel=
sound=
texture=AZUL_AKN
kb_checklists=
kb_reference=
atc_id=PR-AKN
atc_airline=Azul
atc_flight_number=726
atc_parking_codes=ATR,AZU
atc_parking_types=RAMP,CARGO
ui_manufacturer=Traffic Plane
ui_type=ATR72-600
ui_variation=AZUL AKN
description=


Where .x is next number of last [fltsim] on your aircraft.cfg and enjoy.
Where sim=ospatr72-500v6acof replace by your *.air file!
=============================================================================
Major artwork by Alexandre Alves

Alexandre Alves
islander_ktr@hotmail.com
=============================================================================