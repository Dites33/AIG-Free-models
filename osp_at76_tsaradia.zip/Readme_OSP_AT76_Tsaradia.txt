------------------------------------------------------------------------------------------
/////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

Tsaradia repaint for OSP ATR 72-500


Textures only. Original aircraft by Oskari Syynimaa is available in Avsim. (osp_atr_72_500_base.zip)

Design: Christian Muenier (muenier@gmail.com)
https://muenierweb.wordpress.com/


------------------------------------------------------------------------------------------
////////////////////////////////////// INSTALLATION \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


1. Unzip the texture.Tsaradia folder to your osp_atr_72_500 folder.

2. Copy the following [Fltsim.X] section in to aircraft.cfg below existing [fltsim] sections.
Replace the X with the next number in sequence.


[fltsim.X]
title=Tsaradia ATR72-600
sim=ATR72
model=
texture=Tsaradia
atc_id=5R-EJB
atc_airline=AIR MADAGASCAR
ui_manufacturer=Aerospatiale
ui_type=ATR 72-500
ui_variation=Tsaradia
atc_parking_codes=MDG
atc_parking_types=GATE
description=OSP ATR 72-500

------------------------------------------------------------------------------------------
/////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

This repaint is freeware.