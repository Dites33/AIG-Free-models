AI-AARDVARK B717 Hawaiian Airlines.
Thanks for downloading the AI-AARDVARK B717 Hawaiian Airlines
Model/Base Paint/fs2004 fde by David Rawlins
FS2002 FDE by: David Carter
Paint By: Kaveh Payandeh
*****************
TURN ON WORD WRAP
*****************

******
IMPORTANT NOTICE:


THESE FILES MAY ONLY BE UPLOADED TO AVSIM or FLIGHTSIM.COM BY THE ORIGINAL AUTHOR/S. 

THESE FILES MAY NOT BE UPLOADED TO ANY OTHER SITE WITHOUT THE AUTHOR'S WRITTEN PERMISSION. THESE REPAINTS ARE FREEWARE AND MAY NOT BE SOLD, OR PUT ON ANY SITE THAT CHARGES FOR DOWNLOADING FREE FILES. THE FILES FOUND IN THIS ARCHIVE MAY NOT BE DISTRIBUTED ON CD OR ANY MEDIUM FOR ANY KIND OF FEE, INCLUDING THE COST OF PRODUCTION, MATERIALS OR POSTAGE.

Specifically, you DO NOT HAVE PERMISSION to place this file on a DVD or CD and then sell it on Ebay or anywhere else. 


>>>>>>>>READ THIS!!!!<<<<<<<<<<<<


----S P E C I A L N O T E----

This is an AI aircraft and will NOT BE VISIBLE in the aircraft selection window in flight simulator.


>>>>>>>>READ THIS!!!!<<<<<<<<<<<<

******
INSTALLATION:

1) Just drop the "texture.Hawaiian" folder into your "AIA_B717" folder. (The base package (aia_b717.zip) must be downloaded separately to use this paint). 
2) Copy the [fltsim.x] entry supplied into the aircraft.cfg file supplied in the base package mentioned above. Be sure to number them correctly, starting sequentially with [fltsim.0] and working your way up with each additional livery you add...e.g. [fltsim.0], [fltsim.1], [fltsim.2]...making sure not to skip or duplicate any numbers in the sequence.
3) Then assign the aircraft to some flightplans and you're on your way.

For more information or If you're not sure how to assign an aircraft to a flightplan, please visit our website at www.ai-aardvark.com and look in the FAQ/ Help section. Be sure to post any problems you may have in the help section.

********

FS2002
By default the fde for this aircraft is for use in fs2004/fs9. If you are using it in FS2002, replace the "aia_B717.air" & "aircraft.cfg" with the one contained in the "fs2002fde" folder.

********
NOTES

This aircraft was designed specifically for use as an AI aircraft. As such, the primary design criteria were that it look good sitting at the gate, or as seen when landing from an aircraft waiting to take off. 

This plane also uses 8 different LOD (levels of detail) models, which means that as the plane gets visually smaller, the model displayed becomes simpler and simpler, thus reducing the drag on your computer. 

If you download a GMAX aircraft that is just gorgeous, but really chews up your frame rates when used as AI if several of them appear on the screen at once, the designer probably did not use the LOD feature, so the model is always 20,000 polygons no matter how far away from you it is. 

******

AI FLIGHT DYNAMICS (fs2002)

FDE's for AI aircraft are somewhat of a compromise. Dynamics that allow beautiful takeoffs often result in planes that will not land or land very badly. AIA fde's are also designed with traffic flow in mind. This means an AIA aircraft is going to touch down very near the end of the runway and quickly exit to make room for the next aircraft. If you want more "float" on landing, you can adjust the cruise lift, parasite drag and induced drag parameters in the aircraft.cfg file.

******

REPAINTS

Ai Aardvark hopes that you will want to repaint our planes and we have blank paintkit versions of our aircraft available. It comes with a layered photoshop file that includes windows, doors, details, panel lines, shadows and weathering. 

DO NOT USE SOMEONE ELSES REPAINT AS A BASIS FOR YOUR REPAINT WITHOUT FIRST OBTAINING PERMISSION FROM THE ORIGINAL PAINTER!!!
THIS INCLUDES AARDVARK REPAINTS.

We place no restrictions on where repaints are uploaded to, but we would like this readme to be included with all repaints. If you would like your repaint listed on our website, simply upload it to avsim or flightsim.com and be sure to include the word "aardvark" in the file description. Within a week or two, we should find your repaint and list it. DO NOT INCLUDE THE MODEL WITH YOUR REPAINT.



IMPORTANT
Not affiliated with, or endorsed by Hawaiian Airlines or Boeing/McDonnell Douglas Aircraft. Not for commercial sale. 

THIS AIRCRAFT IS FREEWARE. 

*** IMPORTANT!!! ****
THIS MODEL (*.MDL) MAY NOT BE DECOMPILED AND EDITED/MODIFIED IN ANY WAY WITHOUT THE EXPRESS PERMISSION OF THE DESIGNER!!!

*** VISIT THE UNRELIABLE AI AARDVARK WEBSITE WHILE YOU STILL CAN! www.ai-aardvark.com ***

enjoy!

Craig Crawley 
David Rawlins
David Carter 
Boback Shahsafdari
Peter Pavlin 

April 1, 2006

Comments or suggestions:

ai_aardvark@earthlink.net

****Aardvark happily disregards the following types of email messages:

Requests to model a particular aircraft type.
Repaint requests.
"What are you building now?"
Requests for a 767-400, 737-900, or any other unreleased paintkits.
Reports/complaints that the aircraft do not show up in the aircraft selection menu.
Problems associated with trying to fly our aircraft yourself. (Our aircraft are for AI USE ONLY)

We suggest that you ask these sorts of questions in our forum. 