[fltsim.x]
title=FAIB Airbus A320-200 CFM MedSky FSX
sim=FAIB_A320
model=CFM
texture=MedSky
atc_id=
atc_airline=Medsky
atc_flight_number=
ui_manufacturer=MedSky
ui_type=A320-200
ui_variation=MedSky 9H-MSA
description=For AI use only :: Repaint by Kamil Fryzols
atc_parking_types=GATE
atc_parking_codes=MNS
-----------------------------------------------------------------------------------------------------
4.Replace X is by an increasing number according to the number of liveries installed on your aircraft.cfg. Each  [fltsim.x] record must be UNIQUE, example: [fltsim.15],[fltsim.16] etc.

Kamil Fryzol
fryzol1a@gmail.com
JUN, 2022
****************************************************************************************************************************
Enjoy your flight!





