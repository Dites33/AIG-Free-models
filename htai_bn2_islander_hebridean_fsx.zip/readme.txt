Hebridean Air Service BN2 Islander 
Reg: G-HEBS

Textures only. HTAI (Henry Tomkiewicz) Britten-Norman BN2 Islander base model required.
These textures are in DDS format for FSX

Add the folder Texture.hebridean to your BN2 Islander folder.

Add the following to your aircraft .cfg replacing xx with the next consecutive number

[fltsim.xx]
title=AI Britten-Norman BN-2 Hebridean
sim=Britten-Norman BN-2
model=longnose
panel=
sound=
texture=hebridean
kb_checklists=
ui_manufacturer=Britten-Norman
ui_type=BN-2
ui_variation=hebridean
atc_heavy=0
atc_id=G-HEBS
atc_airline=
atc_flight_number=
atc_parking_codes=
atc_parking_types=GATE,RAMP
description=AI Britten-Norman BN-2 Islander by Henry Tomkiewicz


For AI Traffic (FSX)
Repaint by Symon Long
April 2009
cattz@longsite.co.uk
www.longsite.co.uk


