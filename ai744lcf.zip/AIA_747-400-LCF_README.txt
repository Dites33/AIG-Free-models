AI-AARDVARK 747-400 LCF (Dreamlifter)

Thanks for downloading the 747-400 LCF (Dreamlifter)
Orginal model by Craig Crawley, converted to LCF by David Rawlins
Original 747-400 paintkit by Peter Pavlin & Daniel DiBacco, modified for LCF use by David Rawlins


*****************
TURN ON WORD WRAP
*****************

******
IMPORTANT NOTICE:


THESE FILES MAY ONLY BE UPLOADED TO AVSIM or FLIGHTSIM.COM BY THE ORIGINAL AUTHOR/S. 

THESE FILES MAY NOT BE UPLOADED TO ANY OTHER SITE WITHOUT THE AUTHOR'S WRITTEN PERMISSION. THESE REPAINTS ARE FREEWARE AND MAY NOT BE SOLD, OR PUT ON ANY SITE THAT CHARGES FOR DOWNLOADING FREE FILES. THE FILES FOUND IN THIS ARCHIVE MAY NOT BE DISTRIBUTED ON CD OR ANY MEDIUM FOR ANY KIND OF FEE, INCLUDING THE COST OF PRODUCTION, MATERIALS OR POSTAGE.

Specifically, you DO NOT HAVE PERMISSION to place this file on a DVD or CD and then sell it on Ebay or anywhere else. 

THESE FILES MAY NOT BE INCLUDED IN ANY OTHER PACKAGE, OR UPLOADED TO ANY OTHER SITE BESIDES AVSIM or FLIGHTSIM.COM WITHOUT THE EXPRESS WRITTEN PERMISSION OF THE AUTHOR/s.

Also, for you really dense individuals out there who just can't help from grabbing models, repaints and flightplans that you know you do not have permission to use and then uploading your airline packages, you're going to rot in a special hell where you'll be forced to spend an eternity playing with FS98 on a 233mhz computer. This means you, David Hays, Adobe, Tantris, etc and the rest of your kind out in FS Land.


>>>>>>>>READ THIS!!!!<<<<<<<<<<<<


----S P E C I A L N O T E----

This is an AI aircraft and will NOT BE VISIBLE in the aircraft selection window in flight simulator.


******
INSTALLATION:

1) Just drop the "AIA_747-400_LCF folder into your FS4k aircraft folder.  
That's it for installation, all textures are included.

2) Then assign the aircraft to some flightplans and you're on your way.
(Or use the dodgy ones included in this package.)

For more information or If you're not sure how to assign an aircraft to a flightplan, please visit our website at www.ai-aardvark.com and look in the FAQ/ Help section. 


********
NOTES

This aircraft was designed specifically for use as an AI aircraft. As such, the primary design criteria were that it look good sitting at the gate, or as seen when landing from an aircraft waiting to take off. 

This plane also uses 5 different LOD (levels of detail) models, which means that as the plane gets visually smaller, the model displayed becomes simpler and simpler, thus reducing the drag on your computer. 

If you download a GMAX aircraft that is just gorgeous, but really chews up your frame rates when used as AI if several of them appear on the screen at once, the designer probably did not use the LOD feature, so the model is always 20,000 polygons no matter how far away from you it is. 

******

REPAINTS

Ai Aardvark hopes that you will want to repaint our planes but we will not have a blank paintkit for the 747 LCF as all existing repaints are included.  The paintkit that we will not release will not come with a layered photoshop file that includes windows, doors, details, panel lines, shadows and possibly weathering. 




IMPORTANT
Not affiliated with, or endorsed by Douglas or Boeing Aircraft. Not for commercial sale. 

THIS AIRCRAFT IS FREEWARE. 

*** IMPORTANT!!! ****
THIS MODEL (*.MDL) MAY NOT BE DECOMPILED AND EDITED/MODIFIED IN ANY WAY WITHOUT THE EXPRESS PERMISSION OF THE DESIGNER!!!

*** VISIT THE UNRELIABLE AI AARDVARK WEBSITE WHILE YOU STILL CAN! www.ai-aardvark.com ***

enjoy!

Craig Crawley 
David Rawlins
David Carter 
Boback Shahsafdari
Peter Pavlin
Dec 12, 2017

(If you've read down this far, this 747 model and repaints are being released 15 years to the day when AI Aardvark released our very first models, a 737-300 and dc-9)


****Aardvark happily ignores almost all types of email messages these days, but if you're feeling lucky, you're welcome to try this one:

ai_aardvark@earthlink.net

