Conviasa

Thanks for downloading the AI Cessna C208B Conviasa

Model: Henry Tomkiewicz

Painted by:Luis Fernando Villani
E-mail: luisfvillani@hotmail.com

INSTALLATION INSTRUCTIONS:
Just add the following text to your aircraft.cfg file 

