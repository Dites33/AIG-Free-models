Sounds Air Cessna 208B Grand Caravan 
Reg:SAA 
Textures only. HTAI (Henry Tomkiewicz) Cessna 208B Grand Caravan base model required. File name: ai_cessna_c208b_grand_caravan.zip

A modified prop texture is included for use in FSX. It is enclosed in the folder 'fsx_prop'. Just exchange this texture for FSX use. A thumbnail image is also included for FSX.

Add the folder Texture.soundsair to your C208B folder.
If you wish to use the 32bit textures, just copy over the file from the 32bit texture folder and replace.

Add the following to your aircraft .cfg replacing xx with the next consecutive number:

[fltsim.xx]
title=AI Cessna 208B Sounds Air
sim=AI Cessna 208B
model=cp
panel=
sound=
texture=soundsair
kb_checklists=
ui_manufacturer=HTAI
ui_type="208B"
ui_variation=Sounds Air
atc_heavy=0
atc_id=ZK-SAA
atc_airline=
atc_flight_number=
atc_parking_codes=
atc_parking_types=RAMP,GATE
description=AI Cessna 208B Grand Caravan by Henry Tomkiewicz

For AI Traffic
Repaint by Symon Long
April 2012
cattz@longsite.co.uk
www.longsite.co.uk
No responsibilty is accepted for anything that may adversely affect your computer.
Uploading of any textures without permission is not permitted.
