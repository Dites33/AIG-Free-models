Thank you for downloading this AIG flightplan package.

*******************************************************************************

DETAILS:

AUTHORED BY:	Wolfgang Maier
TESTED BY:	Robert Williams & Michael Dean
RELEASED BY:	AIG Alpha-India Group
EMAIL:		wolfganglg.maier@gmail.com
SUPPORT:	www.alpha-india.net/forums/index.php
WEEK:		11th - 17th November 2019

NOTES:		
		
*******************************************************************************
IMPORTANT NOTE:

We would very much like to thank the Alpha-India Team for the effort put in to 
producing and beta testing each flightplan.  Thanks guys!

Our goal is to provide accurate flightplans in order to populate Microsoft 
Flight Simulator with real world traffic throughout the world. These 
flightplans are based on many sources and are the best that we have been 
able to compile. They are accurate to the extent that our data and the 
limitations of the Flight Simulator AI engine allow.

*******************************************************************************

IMPORTANT LEGAL NOTICE:

This package, and its contents, can not be redistributed in any way without the 
author's explicit and written permission.

********************************************************************************

INSTALLATION INSTRUCTIONS:

Flightplans can be installed with AIG's AI Manager, AIFP v3 or manually with
AIG Traffic Tools (AIGTT).

For fastest installation we recommend AIG's AI Manager using One-Click-Installer (OCI)
Available at: https://www.alpha-india.net/forums/index.php?topic=24614


Since we provide accurate cruise speeds for the Flightplans you can leave the 
'Always Use Aircraft.cfg Cruise Speed' in AIFPv3's Options menu unticked.
 
If you want to install the FlightPlans manually, unzip the archive. 
Then go to the Aircraft.txt and change the speed values to 200 (or leave it as is, 
if the speed is already below 200). Save the file and compile the Aircraft, 
Airport, and Flightplan files with AIGTT.

*******************************************************************************

SPECIAL THANKS:

All the beta-testers at AIG. Without them we would not have been able to release 
this flightplan.

*******************************************************************************
