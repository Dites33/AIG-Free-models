Manual "update" of the Ultimate GA Global Express and Global 5000 packages.


Requires the Ultimate Global Express, Global 5000 and Ultimate Global Update packages to already be installed:

			Filename on Avsim.com for FS9/FSX

ultimate_global_express_fs2004_v1.1.zip	/ ultimate_global_express_fsx_v1.1.zip
ultimate_global_5000_fs2004.zip		/ ultimate_global_5000_fsx.zip
ultimate_global_update_fs2004.zip	/ ultimate_global_update_fsx.zip

*Notice!*
This update includes the 4 German Air Force Global 5000's and 5 Vista Jet Global Express/6000's that have been previously been released on Avsim.com.

------------------------

About:

Since the release of the UltimateGA Global Express/XRS, Global 5000 and Global Update packages. Me (Daniel Fall) and Alex Peake have been trying to keep the Global fleet somewhat up to date.

This has obviously been a lot of work and has now come to the point where it is no longer feasible to keep up.

The release of this package does not mean the Global Express fleet is now up to date, this is just how far we got.

Several newly delivered aircraft are not included and several old aircraft that have been repainted or reregged IRL will still be flying.

I would of course have liked to release a more thorough update, and that was the orignal plan. However, the time has come to where me and Alex wont be doing any more AI traffic packages and thus the choice was to upload what we had or just keep them sitting on my hard drive (and in my sim of course).

Some of the included aircraft wont have a flightplan to go with it. I decided to include them anyway but please don't contact me asking for flightplans, I don't have any. From memory they are 9H-VJE, 9M-CJG and OY-LUK.

Finally, 3 or 4 of the aircraft in this update were painted by Thomas Ernst. I hope Thomas wont mind me including them in the release.

------------------------


To install the update:

// Step 1

Open the folder "Aircraft".

Copy all contents (3 aircraft) and paste them into your FS Aircraft folder. 

Overwrite when prompted!

This will leave you with un-used texture folders. If this is not acceptable to you, use one of the utilities available to track them down and remove them.


// Step 2

Remove all Global 5000/Express flightplans you already have installed, should be one BGL for the Express/XRS and one for the Global5000. (Not counting the GAF Global 5000's and Vistajet Globals depening on if and where you have them installed)

Open the folder "Flightplans".

These are flightplans for all Global 5000/6000/Express (that have been painted/planned), including those already released before, that you just removed.

Compile the included flightplan files using your prefered method. The reason for not including the BGLs is to avoid any FS9/FSX compatibility issues.

*Notice*
I have blanked out (//) some aircraft from the flightplans: airframes written off, aircraft re-regged where a new (included) aircraft has taken the old registration as well as aircraft that have been re-regged where I have included a new repaint but no new plan for the new registration.


// Step 3

Open the folder "Voicepacks".

Import these files into your sim using Editvoicepack. Please see Editvoicepack documentation on how to do this if you are unclear. We have only included new voice packs which have not previously been made available to avoid duplication.


-----------------------

If you made it this far, congratulations.

Daniel Fall
danielfall@gmail.com