AI-AARDVARK Fokker 100 Iran Aseman Airlines (2 variations)

Thanks for downloading the Fokker 100 Iran Aseman Airlines repaints.
Repaint by Jakob Tischler [ if you want to cry your heart out: jakob -at- the-fruit-stand.com ]



***Note from the painter:***

		Anyone even thinking about ripping off these repaints may do so with the awareness 
of maybe dying a very slow death in the near, or far, future. Or maybe not.

		Anyone who likes these paints, and hence me, so much that he'd like to use them in his
inappropriately copyrighted AI package, and call this package to the likes of Adobe
or SKAI, may do so for a fee of �29,59 or $39,73 (USD); PayPal is accepted. If you're
not willing to pay the fee, maybe because your mom hasn't given you enough play money
this month, or you're just a sick bastard who thinks he can claim ownership for free,
then for crying out loud, you better leave these paints alone, or start running until
you reach puberty.

'Til we meet again...

Jakob Tischler
16 December 2008

***End of note***



***Special note about variations***

		I could have painted two to three more variations, but then again there's the 
important factor of acute laziness to be counted in. Also, EP-ASM, which has the old
grey belly, but new tail, is stored at the moment, which is reason enough for me not
to do it for now. Then there are also one or two in the fleet which have stair doors
instead of plug doors. For reasons these haven't been painted please consult your 
local pharmacist and/or coroner.

		One other thing: still, after all these years, I'm not sure about IRC's callsign.
Neither the FAA nor Eurocontrol list one, old sources state it's either "Asseman" or
"Iran Asseman". If you have confirmable information on this (and I don't mean the
"my brother told me his sister-io-law's nephew's best friend's dad's military 
buddy's uncle's  gun store clerk's rat said ..." kind), please be so kind and
contact me.

Quick-Draw-Gut-Shot livery assignment (*s mark painted regs):

		- Grey Belly / OC Tail
			*EP-ASG*, EP-ASI, EP-ASJ, EP-ASK, EP-ASL, EP-ASO, EP-ASP, EP-ASQ, EP-ASR, EP-AST

		- Grey Belly / NC Tail
			EP-ASM [stored]
			
		- White Belly / NC Tail
			*EP-ASZ*, EP-ASX, EP-ATB
	
EP-AWZ is currently operated by Iranian Air Transport, but is supposed to come back
into the IRC fleet.

If you're looking for EP-ASU, it's leased out to Kish Air. A repaint is available
at Avsim (aif100ir.zip)

***End of variations note***		

________________________________________________________________________________________________

****************
  [FLTSIM.X]
****************

[fltsim.x]
title=AIA Fokker 100 Iran Aseman Airlines 'New Colors'
sim=aia_FOKKER_100
model=no_refl
texture=Iran Aseman Airlines 'New Colors'
atc_id=EP-ASZ
atc_airline=Iran Asseman
atc_flight_number=1208
ui_manufacturer=Aardvark
ui_type=Fokker 100
ui_variation=Fokker 100 Iran Aseman Airlines 'New Colors'
description=Fokker 100 Iran Aseman Airlines 'New Colors' :: Repaint by Jakob Tischler
atc_id_color=0x00000000
visual_damage=0
atc_heavy=0
atc_parking_codes=IRC
atc_parking_types=GATE
atc_id_font=Verdana,-11,1,600,0

[fltsim.x+1]
title=AIA Fokker 100 Iran Aseman Airlines 'Old Colors'
sim=aia_FOKKER_100
model=no_refl
texture=Iran Aseman Airlines 'Old Colors'
atc_id=EP-ASG
atc_airline=Iran Asseman
atc_flight_number=1208
ui_manufacturer=Aardvark
ui_type=Fokker 100
ui_variation=Fokker 100 Iran Aseman Airlines 'Old Colors'
description=Fokker 100 Iran Aseman Airlines 'Old Colors' :: Repaint by Jakob Tischler
atc_id_color=0x00000000
visual_damage=0
atc_heavy=0
atc_parking_codes=IRC
atc_parking_types=GATE
atc_id_font=Verdana,-11,1,600,0



________________________________________________________________________________________________



*****************
TURN ON WORD WRAP
*****************

******
IMPORTANT NOTICE:


THESE FILES MAY ONLY BE UPLOADED TO AVSIM or FLIGHTSIM.COM BY THE ORIGINAL AUTHOR/S.

THESE FILES MAY NOT BE UPLOADED TO ANY OTHER SITE WITHOUT THE AUTHOR'S WRITTEN PERMISSION. THESE REPAINTS ARE FREEWARE AND MAY NOT BE SOLD, OR PUT ON ANY SITE THAT CHARGES FOR DOWNLOADING FREE FILES. THE FILES FOUND IN THIS ARCHIVE MAY NOT BE DISTRIBUTED ON CD OR ANY MEDIUM FOR ANY KIND OF FEE, INCLUDING THE COST OF PRODUCTION, MATERIALS OR POSTAGE.

Specifically, you DO NOT HAVE PERMISSION to place this file on a DVD or CD and then sell it on Ebay or anywhere else.

THESE FILES MAY NOT BE INCLUDED IN ANY OTHER PACKAGE, OR UPLOADED TO ANY OTHER SITE BESIDES AVSIM or FLIGHTSIM.COM WITHOUT THE EXPRESS WRITTEN PERMISSION OF THE AUTHOR/s.

Also, for you really dense individuals out there who just can't help from grabbing models, repaints and flightplans that you know you do not have permission to use and then uploading your airline packages, you're going to rot in a special hell where you'll be forced to spend an eternity playing with FS98 on a 233mhz computer. This means you, David Hays, Adobe, Tantris, SKAi, etc and the rest of your kind out in FS Land.




>>>>>>>>READ THIS!!!!<<<<<<<<<<<<


----S P E C I A L N O T E----

This is an AI aircraft and will NOT BE VISIBLE in the aircraft selection window in flight simulator.


ALSO: >>ONLY LOSERS STEAL LIGHTMAPS!<<
******



******
INSTALLATION:

1) Just drop the "texture.Iran Air 'EP-CFD'", "texture.Iran Air 'EP-IFE'", "texture.Iran Air 'EP-IFJ'", "texture.Iran Air 'EP-CFK'", "texture.Iran Air 'EP-CFO'" and "texture.Iran Air 'EP-IDD'" folders into your "AIA_FOKKER_100" folder. (The base package (aiaFk100.zip) must be downloaded separately to use this paint).
2) Copy the [fltsim.x] entries supplied into the aircraft.cfg file supplied in the base package mentioned above. Be sure to number them correctly, starting sequentially with [fltsim.0] and working your way up with each additional livery you add...e.g. [fltsim.0], [fltsim.1], [fltsim.2]...making sure not to skip or duplicate any numbers in the sequence.
3) Then assign the aircraft to some flightplans and you're on your way.

For more information or If you're not sure how to assign an aircraft to a flightplan, please visit our website at www.ai-aardvark.com and look in the FAQ/ Help section.

********


********
NOTES

This aircraft was designed specifically for use as an AI aircraft. As such, the primary design criteria were that it look good sitting at the gate, or as seen when landing from an aircraft waiting to take off.

This plane also uses 5 (woo hoo!!) different LOD (levels of detail) models, which means that as the plane gets visually smaller, the model displayed becomes simpler and simpler, thus reducing the drag on your computer.

If you download a GMAX aircraft that is just gorgeous, but really chews up your frame rates when used as AI if several of them appear on the screen at once, the designer probably did not use the LOD feature, so the model is always 20,000 polygons no matter how far away from you it is.

******

REPAINTS

Ai Aardvark hopes that you will want to repaint our planes and we have blank paintkit versions of our aircraft available. It comes with a layered photoshop file that includes windows, doors, details, panel lines, shadows and possibly weathering.

DO NOT USE SOMEONE ELSES REPAINT AS A BASIS FOR YOUR REPAINT WITHOUT FIRST OBTAINING PERMISSION FROM THE ORIGINAL PAINTER!!!
DO NOT STEAL SOMEONE ELSES LIGHTMAP FOR YOUR REPAINT, MAKE YOUR OWN!
THIS INCLUDES AARDVARK REPAINTS.

We place no restrictions on where repaints are uploaded to, but we would like this readme to be included with all repaints. DO NOT INCLUDE THE MODEL WITH YOUR REPAINT.



IMPORTANT
Not affiliated with, or endorsed by Fokker or Iran Air. Not for commercial sale.

THIS AIRCRAFT IS FREEWARE.

*** IMPORTANT!!! ****
THIS MODEL (*.MDL) MAY NOT BE DECOMPILED AND EDITED/MODIFIED IN ANY WAY WITHOUT THE EXPRESS PERMISSION OF THE DESIGNER!!!

*** VISIT THE UNRELIABLE AI AARDVARK WEBSITE WHILE YOU STILL CAN! www.ai-aardvark.com ***

enjoy!

Craig Crawley
David Rawlins
David Carter
Boback Shahsafdari
Peter Pavlin

July, perhaps even August, 2008


****Aardvark happily ignores almost all types of email messages these days, but if you're feeling lucky, you're welcome to try this one:

ai_aardvark@earthlink.net