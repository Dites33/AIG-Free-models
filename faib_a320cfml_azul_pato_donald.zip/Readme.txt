[fltsim.x]
title=FAIB Airbus A320S NEO Azul Linhas Aereas Pato Donald PR-YSI
sim=FAIB_A320
model=CFML_S
texture=Azul Pato Donald PR-YSI
atc_airline=AZUL
ui_manufacturer=Azul Linhas Aereas
ui_type=A320-200neo
ui_variation=Azul Linhas Aereas
ui_createdby=FAIB
description=FAIB A320 Azul Linhas Aereas Pato Donald PR-YSI -- Repaint by Kamil Fryzol.
atc_parking_codes=AZU
atc_parking_types=GATE
-----------------------------------------------------------------------------------------------------
4.Replace X is by an increasing number according to the number of liveries installed on your aircraft.cfg. Each  [fltsim.x] record must be UNIQUE, example: [fltsim.15],[fltsim.16] etc.

Kamil Fryzol
fryzol1a@gmail.com
APR, 2022
****************************************************************************************************************************
Enjoy your flight!





