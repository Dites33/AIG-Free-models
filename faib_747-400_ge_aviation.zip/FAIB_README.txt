FAIB - FSX AI Bureau BOEING 747-400 Base Models Pack.

Model, base paint, lightmap, FSX FDE by Erez Werber, FS9 FDE by Erez Werber
Parts of readme based on TFS's readme.
Nose steering XML code by Flusirainer.

*****************
Contact: contact@fsxaibureau.com
*****************

*****************
TURN ON WORD WRAP
*****************

******
IMPORTANT NOTICE:

DO NOT INCLUDE THE BASE MODELS IN YOUR REPAINT PACKAGES!!

>>>>>>>>READ THIS TOO!!!! THE EULA!!<<<<<<<<<<<<

THESE FILES MAY ONLY BE UPLOADED TO AVSIM or FLIGHTSIM.COM BY THE ORIGINAL AUTHOR/S.

THESE FILES SHOULD NOT BE UPLOADED TO http://www.fs2000.org.
Questi file non deve essere caricate http://www.fs2000.org.
DO NOT UPLOAD THESE FILES TO http://www.fs2000.org.
Non caricare questi file http://www.fs2000.org.

THESE FILES MAY NOT BE UPLOADED TO ANY OTHER SITE WITHOUT THE AUTHOR'S WRITTEN PERMISSION. THESE REPAINTS ARE FREEWARE AND MAY NOT BE SOLD, OR PUT ON ANY SITE THAT CHARGES FOR DOWNLOADING FREE FILES. THE FILES FOUND IN THIS ARCHIVE MAY NOT BE DISTRIBUTED ON CD OR ANY MEDIUM FOR ANY KIND OF FEE, INCLUDING THE COST OF PRODUCTION, MATERIALS OR POSTAGE.

Specifically, you DO NOT HAVE PERMISSION to place this file on a DVD or CD and then sell it on Ebay, Aldi, 7-Eleven, Rakuten or anywhere else.

DON'T INCLUDE THIS AIRPLANE IN COPYRIGHT INFRINGING PACKAGES SUCH AS THOSE MADE BY SKAI, ADOBE, TANTRIS, ICE, GAI ETC.

THESE MODELS ARE NOT TO BE USED FOR COMMERCIAL PROFESSIONAL FLIGHT SIM TRAINING IN ENVIRONMENT SUCH AS MICROSOFT ESP OR LOCKHEED-MARTIN PREPAR3D WITHOUT PRIOR PERMISSION FORM FAIB!!!!

PERSONAL NON-COMMERCIAL USE IN LOCKHEED-MARTIN PREPAR3D IS ALLOWED.

>>>>>>>>READ THIS!!!!<<<<<<<<<<<<

----SUPPORTING FAIB----

Making an AI model takes a lot of time if you appreciate my work please donate through the website @ FSXAIBureau.com Thank you.

----SPECIAL NOTE----

In FS9 this is an AI aircraft and will NOT BE VISIBLE in the aircraft selection window in flight simulator. However if you want it to be visible in the aircraft selection window, you have to edit the "FAIB_7474.air" file with the program "AirEd" (available (if not corrupt) at AVSIM "aired.zip"), change "Aircraft Type" from "2" to "0".
In FSX you will need to add a panel and sound folder for the plane to be visible in the aircraft selection menu.

NO SUPPORT IS GIVEN TO HUMAN PILOTS, AI PILOTS ARE FREE TO CONTACT US ABOUT TRAINING AND CERTIFICATION.

----NORMAL NOTE----

This aircraft was designed specifically for use as an AI aircraft. As such, the primary design criteria were that it look good sitting at the gate, or as seen when landing from an aircraft waiting to take off.

This aircraft feature 7 LOD'S for optimal performance, to learn more about LOD'S and why they are important go here: http://en.wikipedia.org/wiki/Level_of_detail

FSX models features Toggle able landing lights, logo lights ,taxi lights, wing flex and UHD 4096X4096 textures.

---WING FLEX NOTE---

Using FS9? There are no wing flex models for FS9 since it does not support skinned animation.
Using Wing flex models in FSX? Make sure you have skinned animations turned on in the graphic options.
Don't want wing flex in FSX? Use the NWF (No Wing Flex) models instead of the regular models, make sure to uncomment the needed light section in the aircaft.cfg file or you will not have navigation lights and strobes.

---FSX ONLY IMPORTANT NOTE---

To prevent performance issues you must copy the content of the included "PLACE INSIDE YOUR FSX MAIN TEXTURE FOLDER" folder into your FSX main texture folder.

**** NEW NEW NEW ****
Inside the EXTRA folder you will find the LOGO LIGHT ALWAYS ON folder which includes special always on textures designed to give you logo light illumination at all times similar to UT2 models.
Simply copy these textures to your MAIN FSX TEXTURE folder and overwrite.
Because of changes designed to reduce memory footprint this always on logo light will become brighter once the aircraft actually turns on the logo lights as opposed to older FAIB models where this did not happen.

---PAINT KIT INFO---

A paint kit is available separately on FAIB's website.

---Shockwave Lights---

Location for Shockwave lights are included in the aircraft.cfg's, however you still need to un-comment them.
Look at the [LIGHTS] section of the aircraft.cfg files for more info.

---FSX door locations---

Door locations are included in the FSX aircraft.cfg's.

---FSX Only Known Issues---

After landing and generally when braking AI pilots will tend to lock the wheels.
Lights such as strobes, nav lights etc tend to move out of position over time.
Several areas of the plane cannot be lighted using the light map, this is an FSX limitation.
Models with wing flex have weak wingtip lights which diminish over distance quickly and are NOT visible from great distances, you can use the NWF (No Wing Flex) models to avoid this and use the standard aircraft.cfg lights which are visible.

>>>>>>>>READ THIS!!!!<<<<<<<<<<<<

******

INSTALLATION FSX:

1) Move all folders inside this archives FSX folder into your FSX AI aircraft folder or your Airplane folder located within the SimObjects folder.
2) Copy all files from the folder "PLACE INSIDE YOUR FSX MAIN TEXTURE FOLDER" into your main FSX texture folder.
3) Copy all files from the folder "PLACE INSIDE YOUR FSX EFFECTS FOLDER" into your main FSX effects folder.
4) Download a few liveries for it. (Available as separate downloads)
5) Copy the texture folder from the livery download into the correct aircraft folder.
6) Copy the [fltsim.x] entry supplied with the livery into the aircraft.cfg file supplied in this base package. Be sure to number them correctly, starting sequentially with [fltsim.0] and working your way up with each additional livery you add...e.g. [fltsim.0], [fltsim.1], [fltsim.2]...making sure not to skip or duplicate any numbers in the sequence.
7) Be sure when filling in your [fltsim.x] entries that you pay special attention to which model you are needing to use.
8) Then assign the aircraft to some flightplans and you're on your way.

INSTALLATION FS9:

1) Move all folders inside this archives FS9 folder into your FS2004 (FS9) aircraft folder.
2) Copy all files from the folder "PLACE INSIDE YOUR FS9 EFFECTS FOLDER" into your main FSX effects folder.
3) Download a few liveries for it. (Available as separate downloads)
4) Copy the texture folder from the livery download into the correct aircraft folder.
5) Copy the [fltsim.x] entry supplied with the livery into the aircraft.cfg file supplied in this base package. Be sure to number them correctly, starting sequentially with [fltsim.0] and working your way up with each additional livery you add...e.g. [fltsim.0], [fltsim.1], [fltsim.2]...making sure not to skip or duplicate any numbers in the sequence.
6) Be sure when filling in your [fltsim.x] entries that you pay special attention to which model you are needing to use.
7) Then assign the aircraft to some flightplans and you're on your way.


For more information or If you're not sure how to assign an aircraft to a flightplan, please visit our website at http://fsxaibureau.com and look in the FAQ / Help section of our forums. You may post any problems you may have or bugs you may find in our forum.

*******


*** IMPORTANT!!! ****
Not affiliated with, or endorsed by BOEING, Not for commercial sale.

THIS AIRCRAFT IS FREEWARE AND SHOULD NOT BE UPLOADED TO http://www.fs2000.org.

*** IMPORTANT!!! ****
THIS MODEL (*.MDL) MAY NOT BE DECOMPILED AND EDITED/MODIFIED IN ANY WAY WITHOUT THE EXPRESS PERMISSION OF THE DESIGNER!!!

*** visit us! http://fsxaibureau.com ***

Thanks to all the great people who keep this hobby alive and the following people for their help delivering this model:
Andy Carroll
Philippe Tabatchnik
Juergen Baumbusch
Craig Ritchie
Mariano Bonaccorso
Frank Severino
Gerry Lewis
Nils Bindauf
Johan Clausen
Robert Williams
Axel Huettemann
Joshua Dean
Bruno Saraiva
Kyle Meeks
Juan Sebastian Gonzalez
Jon Hanf
Marco Wolfsegger
Brian Wheatley

August 2015


Comments:

comments @ fsxaibureau.com
