Painters Readme and Legal note
==============================

by Ronald Kohls (RK), September 2017
Paint Copyright Ronald Kohls
All rights reserved.
Email: Shutt(at)web.de

1. You may not modify and redistribute my paints anywhere else or on any medium. Converted textures (i.g. for FS9) are strictly for personal use only and may not be re-uploaded anywhere.

2. My paints are FREEWARE and may not be sold or put on a site that charges to download.

3. Not authorised by or affliated in any way with the airline or aircraft manufacturer referred to or displayed on included textures. All copyrights remain theirs.

4. Model/paintkit Copyright Erez Weber/FAIB. See FAIB_Readme.

This is a AI repaint for FSX/P3D only.
You may convert the texture for FS9 via http://kaese2002.blogspot.de/p/blog-page.html.
No support provided by me. No liability accepted for any issues arising from converting these textures to FS9 format.

Model: FAIB Boeing 747-400 for FSX/P3D, this is an AI aircraft.
Textures: UHD/HD, mipped/non-mipped, native FSX/P3D DDS DXT5 format

1. Make sure that you installed the model correctly.
2. Put the contents of fltsim.txt in sequence to the aircraft.cfg and check the numbering.
3. Enjoy.