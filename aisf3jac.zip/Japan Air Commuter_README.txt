Saab 340 Japan Air Commuter (2 variations).

Model by Craig Ritchie
Base Paint by Tony Fosler, Jakob Tischler and Craig Ritchie
FS2004 FDE by Steve Tran
Paint By: Boris Le Veve (borisintaipei@gmail.com))

*****************
TURN ON WORD WRAP
*****************

******
IMPORTANT NOTICE:


THESE FILES MAY ONLY BE UPLOADED TO AVSIM or FLIGHTSIM.COM BY THE ORIGINAL AUTHOR/S.

THESE FILES MAY NOT BE UPLOADED TO ANY OTHER SITE WITHOUT THE AUTHOR'S WRITTEN PERMISSION. THESE REPAINTS ARE FREEWARE AND MAY NOT BE SOLD, OR PUT ON ANY SITE THAT CHARGES FOR DOWNLOADING FREE FILES. THE FILES FOUND IN THIS ARCHIVE MAY NOT BE DISTRIBUTED ON CD OR ANY MEDIUM FOR ANY KIND OF FEE, INCLUDING THE COST OF PRODUCTION, MATERIALS OR POSTAGE.

Specifically, you DO NOT HAVE PERMISSION to place this file on a DVD or CD and then sell it on Ebay or anywhere else.


>>>>>>>>READ THIS!!!!<<<<<<<<<<<<

******
INSTALLATION:

1) Just drop the "texture.Japan Air Commuter" & "texture.Japan Air Commuter_8887" folders into your "TFS_Saab_340" folder. (The base package (tfssf3.zip) must be downloaded separately to use this paint).
2) Copy the [fltsim.x] entry supplied into the aircraft.cfg file supplied in the base package mentioned above. Be sure to number them correctly, starting sequentially with [fltsim.0] and working your way up with each additional livery you add...e.g. [fltsim.0], [fltsim.1], [fltsim.2]...making sure not to skip or duplicate any numbers in the sequence.
3) Then assign the aircraft to some flightplans and you're on your way.

For more information or If you're not sure how to assign an aircraft to a flightplan, please visit our website at http://www.the-fruit-stand.com and look in the FAQ / Help section of our forums. Be sure to post any problems you may have or bugs you may find in our forum.


*** IMPORTANT!!! ****
Not affiliated with, or endorsed by Japan Air Commuter or Svenska Aeroplan AB. Not for commercial sale.

THIS AIRCRAFT IS FREEWARE.

*** IMPORTANT!!! ****
THIS MODEL (*.MDL) MAY NOT BE DECOMPILED AND EDITED/MODIFIED IN ANY WAY WITHOUT THE EXPRESS PERMISSION OF THE DESIGNER!!!

*** VISIT THE TASTY FRUIT STAND WEBSITE! http://www.the-fruit-stand.com ***

REQUEST MORE BEFORE THE BIG SNOW COMES!

Tony Fosler
Robert Smith
Federico Permutti
Denis Schranz
Jakob Tischler
Heiko Schmidt
Boris Le Veve
Walter Zimmermann
Craig Ritchie
Jaime Correa
Arnaud Solvay
John Massey
David Freed
David Rawlins
Boback Shahsafdari
Phillip Tan
Chris Reuter
Steve Tran
Jonathan Barton
Ralf Winkler

**Independent Guest Painter**
----->escaped<-------


Early December, 2008


Comments or suggestions:

comments@the-fruit-stand.com