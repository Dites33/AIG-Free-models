Air Kiribati De Havilland Canada DHC6 Twin Otter T3-AKL Repainted by Hernan Anibarro. Textures only. Model by Henry Tomkiewicz (HTAI), DHC6 Twin Otter, model by Henry Tomkiewicz (HTAI /PAI) base models required.

Installation:

Place the folder "Air Kiribati AI DHC6" in your Flight Simulator/aircraft folder. Make sure you replace the "x" in the [fltsim.x] in the proper sequence.

Enjoy your flight!

Hernan Anibarro
anibarro-air@earthlink.net
Fefruary, 2016