Thank you for downloading my repaint package for the representatibe fleet of McDonnell Douglas MD-80s, registrations listed below, flown by Taban Air of Iran.  This airline is based out of Mashhad International Airport in Mashhad, and headquarted in Tehran.  More information on this airline can be found on their website (http://www.taban.aero/) and on Wikipedia (http://en.wikipedia.org/wiki/Taban_Air).

This package contains the following repaints:

Iranian Registrations:
EP-ARA (MD-82): White with stripes
EP-TBB (MD-88): White with grey belly
EP-TBC (MD-88): White with grey belly and stripes

Ukrainian Registrations:
UR-CIY (MD-88): White with grey belly and stripes, tail markings only; same scheme for UR-CIX, UR-CJK

For this package, you will need the following model:

AI Aardvark MD-8x:	http://www.flightsim.com/vbfs/fslib.php?do=copyright&fid=91205

You will need the "Screwdriver Tail" non-reflective model (SD-no_refl) for these repaints.

These textures are available in 32-bit 888-8 and 16-bit DXT3 (with and without MIPmaps) formats.

Thanks go to David Rawlins, aka AI Aardvark, for the model and paintkit - among many, many others.

Please do not distribute these files without permission.  This especially applies to Fly Away Simulation.  I can be reached by e-mail at teamnutmeg (at) gmail (dot) com.

--------------------------------------------------------------

To use this package:

1) If you don't already have them, download the base files for the model from the links provided above.


2) Extract the model folders from their respective .zip files to your aircraft folder.  By default, the aircraft folder is located at:

FS2004:	C:\Program Files\Microsoft Games\FS2004\Aircraft
FSX:	C:\Program Files\Microsoft Games\Microsoft Flight Simulator X\SimObjects\Airplanes

(If you're running a 64-bit version of Windows, the default location will be in "Program Files (x86)" not "Program Files".)

You will need the SD_no_refl model for this repaint.


3) To install the textures, choose one of the packages which corresponds to your version of the sim, and then choose 32-bit or DXT3 (if in doubt, use the DXT3 files).  Copy the paintscheme folders to the corresponding aircraft folder.

	Example: "This Package\texture.Taban Air EP-ARA" copies to "Aircraft\AIA_MD_8X"


4) Open the aircraft.cfg file with Notepad or Wordpad.  You should see at least 1 entry beginning with "[fltsim.xxx]" numbering upward from 0.  Go to the last of these entries (right before the "[General]" section), and take note of the number of the last entry.  Then copy-and-paste the corresponding "[fltsim]" entry from the "Add to Aircraft.cfg.txt" file in this package right after the last entry, and before the "[General]" section.  If you have just installed the model, you will see a note at the beginning of the file telling you where to paste this new entry.


5) Change the "x" in the [fltsim.x] line on the newly-pasted entry to the next number.  If you've just downloaded the model, this will need to be "0", as the AIA MD-8x model does not include any default schemes.

Enjoy!

Chris "TeamNutmeg" Thompson