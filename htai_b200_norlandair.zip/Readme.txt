Norlandair Beechcraft Super King Air 200 TF-NLB

Readme based on TFS's readme file.
Model and Basepaint by Henry Tomkiewicz
Paint By: Thecheesemeister (contact me at the AIG forums http://www.alpha-india.net/forums/)

*****************
TURN ON WORD WRAP
*****************

******
IMPORTANT NOTICE:


THESE FILES MAY ONLY BE UPLOADED TO AVSIM or FLIGHTSIM.COM BY THE ORIGINAL AUTHOR/S.

THESE FILES MAY NOT BE UPLOADED TO ANY OTHER SITE WITHOUT THE AUTHOR'S WRITTEN PERMISSION. THESE REPAINTS ARE FREEWARE AND MAY NOT BE SOLD, OR PUT ON ANY SITE THAT CHARGES FOR DOWNLOADING FREE FILES. THE FILES FOUND IN THIS ARCHIVE MAY NOT BE DISTRIBUTED ON CD OR ANY MEDIUM FOR ANY KIND OF FEE, INCLUDING THE COST OF PRODUCTION, MATERIALS OR POSTAGE.

Specifically, you DO NOT HAVE PERMISSION to place this file on a DVD or CD and then sell it on Ebay, Aldi, 7-Eleven, Rakuten or anywhere else.

DON'T INCLUDE THIS AIRPLANE IN COPYRIGHT INFRINGING PACKAGES SUCH AS THOSE MADE BY SKAI, ADOBE, TANTRIS, ICE, GAI ETC.
*******

This package contains 2 sets of textures, DXT3 bitmaps for FS9 and DXT5 dds for FSX. Select the correct texture set from within the texture.FNA folder.

The Base Model for these textures is available here: http://htai-models.com/downloads.html
You can find flightplans for TF-NLB on the AIG forums: http://www.alpha-india.net/forums/ within the Air Iceland Summer 16 package, which will eventually also be uploaded to avsim.