Azul Conecta Special colors PR-CRF
repaints for HTAI C208B
Brazil, March, 2023
=============================================================================
For install, unzip the texture.XXX into your HTAI C208B folder and ADD
the lines bellow into your aircraft.cfg

[fltsim.x]
title=C208 AZUL CONECTA RE
sim=AI Cessna 208B
model=cp
panel=
sound=
texture=AZULCONECTA_RE
ui_manufacturer=Cessna
ui_type=C208B
ui_variation="PR-CRF"
atc_heavy=0
atc_id=PR-CRF
atc_airline=TWOFLEX
atc_flight_number=
atc_parking_codes=OWT,TWO,ACN
atc_parking_types=RAMP
description=AI Cessna 208B Grand Caravan by Henry Tomkiewicz and Repainted by Alexandre Alves


Where .x is next number of last [fltsim] on your aircraft.cfg and enjoy.
=============================================================================
Major artwork by Alexandre Alves

Alexandre Alves
islander_ktr@hotmail.com
=============================================================================