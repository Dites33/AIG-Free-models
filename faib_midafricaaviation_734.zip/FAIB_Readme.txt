FAIB - FSX AI Bureau BOEING 737-400 Base Models Pack V1.1.

Model, base paint, lightmap, FDE by Erez Werber
Parts of readme based on TFS's readme.
Nose steering XML code by Flusirainer.

*****************
Contact: contact@fsxaibureau.com
*****************

*****************
TURN ON WORD WRAP
*****************

******
IMPORTANT NOTICE:

DO NOT INCLUDE THE BASE MODELS IN YOUR REPAINT PACKAGES!!

>>>>>>>>READ THIS TOO!!!!<<<<<<<<<<<<

THESE FILES MAY ONLY BE UPLOADED TO AVSIM or FLIGHTSIM.COM BY THE ORIGINAL AUTHOR/S.

THESE FILES SHOULD NOT BE UPLOADED TO http://www.fs2000.org.
Questi file non deve essere caricate http://www.fs2000.org.
DO NOT UPLOAD THESE FILES TO http://www.fs2000.org.
Non caricare questi file http://www.fs2000.org.

THESE FILES MAY NOT BE UPLOADED TO ANY OTHER SITE WITHOUT THE AUTHOR'S WRITTEN PERMISSION. THESE REPAINTS ARE FREEWARE AND MAY NOT BE SOLD, OR PUT ON ANY SITE THAT CHARGES FOR DOWNLOADING FREE FILES. THE FILES FOUND IN THIS ARCHIVE MAY NOT BE DISTRIBUTED ON CD OR ANY MEDIUM FOR ANY KIND OF FEE, INCLUDING THE COST OF PRODUCTION, MATERIALS OR POSTAGE.

Specifically, you DO NOT HAVE PERMISSION to place this file on a DVD or CD and then sell it on Ebay, Aldi, 7-Eleven, Rakuten or anywhere else.

DON'T INCLUDE THIS AIRPLANE IN COPYRIGHT INFRINGING PACKAGES SUCH AS THOSE MADE BY ADOBE, TANTRIS, ICE ETC.

THESE MODELS ARE NOT TO BE USED FOR PROFESSIONAL FLIGHT SIM TRAINING IN ENVIRONMENT SUCH AS MICROSOFT ESP OR LOCKHEED-MARTIN PREPAR3D WITHOUT PRIOR PERMISSION FORM FAIB!!!!

>>>>>>>>READ THIS!!!!<<<<<<<<<<<<

----SUPPORTING FAIB----

Making an AI model takes a lot of time if you appreciate my work please donate through the website @ FSXAIBureau.com Thank you.

----SPECIAL NOTE----

This is an AI aircraft and will NOT BE VISIBLE in the aircraft selection window in flight simulator. However if you want it to be visible in the aircraft selection window, you have to edit the "FAIB_7374.air" file with the program "AirEd" (available (if not corrupt) at AVSIM "aired.zip"), change "Aircraft Type" from "2" to "0".

NO SUPPORT IS GIVEN TO HUMAN PILOTS, AI PILOTS ARE FREE TO CONTACT US ABOUT TRAINING AND CERTIFICATION.

----NORMAL NOTE----

This aircraft was designed specifically for use as an AI aircraft. As such, the primary design criteria were that it look good sitting at the gate, or as seen when landing from an aircraft waiting to take off.

This aircraft feature 6 LOD'S for optimal performance, to learn more about LOD'S and why they are important go here: http://en.wikipedia.org/wiki/Level_of_detail

FSX models features Toggle able landing lights, logo lights and taxi lights, and HD 2048X2048 textures.

---IMPORTANT NOTE---

FSX ONLY NOTE:
to prevent performance issues you must have a copy of the included texture FAIB_737_400_AlwaysOn_L.bmp inside your FSX main texture folder.

---PAINT KIT INFO---

A paint kit is available separately on FAIB's website.

---Shockwave Lights---

Location for Shockwave lights are included in the aircraft.cfg's, however you still need to un-comment them.
Look at the [LIGHTS] section of the aircraft.cfg files for more info.

---FSX door locations---

Door loctions are included in the FSX aircraft.cfg's.

---FSX Only Known Issues---

After landing and generaly when braking AI pilots will tend to lock the wheels.
Lights such as strobes, nav lights etc tend to move out of position over time.
Several areas of the plane cannot be lighted using the light map consult the paint kit for more info.

---Service Pack 1 updates---

FSX: 
1. Tail horizontal Dihedral angle fixed.
2. Adjusted FDE weight for appropriate runway selection.
3. Adjusted FDE to lengthen landing roll.
4. Engine fans were rotating the wrong way.
5. Contact points reworked.
6. Aircraft radius updated for correct gate selection.

FS9:
1. Tail horizontal Dihedral angle fixed.
2. Adjusted the last levels of LOD to prevent the model disappearing in rare situations.
3. Adjusted FDE to take off earlier and brake harder during landings.
4. FS9 models had reflection turned on by mistake, switched them off.
5. Contact points reworked.

If you are updating an existing installation you will need to copy all of your existing [fltsim.x] sections into the new supplied aircraft.cfg file for some of the fixes to take effect.

>>>>>>>>READ THIS!!!!<<<<<<<<<<<<

******
NOTE THE FOLLOWING NAME CONVENTIONS:
FAIB_B737-400_L  - Logo light 737-400
FAIB_B737-400_N  - NO Logo light 737-400
FAIB_B737-400_W  - Winglet equipped 737-400

INSTALLATION FSX:

1) Move all folders inside the Base Models\FSX folder into your FSX AI aircraft folder.
2) Copy the texture named FAIB_737_400_AlwaysOn_L.bmp from the folder "PLACE INSIDE YOUR FSX MAIN TEXTURE FOLDER" into your main FSX texture folder.
3) Download a few liveries for it. (Available as separate downloads), or use the included "Blank Livery" textures and skip 3-5
4) Copy the texture folder from the livery download into the correct variant folder (either logo light\normal\winglets).
5) Copy the [fltsim.x] entry supplied with the livery into the aircraft.cfg file supplied in this base package. Be sure to number them correctly, starting sequentially with [fltsim.0] and working your way up with each additional livery you add...e.g. [fltsim.0], [fltsim.1], [fltsim.2]...making sure not to skip or duplicate any numbers in the sequence.
6) Be sure when filling in your [fltsim.x] entries that you pay special attention to which model you are needing to use.
7) Then assign the aircraft to some flightplans and you're on your way.

INSTALLATION FS9:

1) Move all folders inside the Base Models\FS9 folder into your FS2004 (FS9) aircraft folder.
2) Download a few liveries for it. (Available as separate downloads), or use the included "Blank Livery" textures and skip 3-5
3) Copy the texture folder from the livery download into the correct variant folder (either logo light\normal\winglets).
4) Copy the [fltsim.x] entry supplied with the livery into the aircraft.cfg file supplied in this base package. Be sure to number them correctly, starting sequentially with [fltsim.0] and working your way up with each additional livery you add...e.g. [fltsim.0], [fltsim.1], [fltsim.2]...making sure not to skip or duplicate any numbers in the sequence.
5) Be sure when filling in your [fltsim.x] entries that you pay special attention to which model you are needing to use.
6) Then assign the aircraft to some flightplans and you're on your way.


For more information or If you're not sure how to assign an aircraft to a flightplan, please visit our website at http://fsxaibureau.com and look in the FAQ / Help section of our forums. You may post any problems you may have or bugs you may find in our forum (When they become active).

*******


*** IMPORTANT!!! ****
Not affiliated with, or endorsed by BOEING, Not for commercial sale.

THIS AIRCRAFT IS FREEWARE AND SHOULD NOT BE UPLOADED TO http://www.fs2000.org.

*** IMPORTANT!!! ****
THIS MODEL (*.MDL) MAY NOT BE DECOMPILED AND EDITED/MODIFIED IN ANY WAY WITHOUT THE EXPRESS PERMISSION OF THE DESIGNER!!!

*** visit us! http://fsxaibureau.com ***

Thanks to all the great people who keep this hobby alive and the following people for their help delivering this model:
Ben Clark
Andy Carroll
Philippe Tabatchnik
Juergen Baumbusch
Craig Ritchie
Mariano Bonaccorso
Frank Severino
Gerry Lewis
Nils Bindauf
Johan Clausen

July 2012


Comments:

comments @ fsxaibureau.com