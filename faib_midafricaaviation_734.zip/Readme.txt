Mid Africa Aviation 737-400 repaint by Robert Williams for FAIB

===Information===
Model: FSX AI Bureau (FAIB)
Paint Kit: Erez Werber (FAIB)
Author: Robert Williams
Tester: 

***These textures are for use with the LOGOLIGHT model***


===Copyright===
This paint is not to be modified without my permission. It must not be redistributed on other internet sites or included in any AI packages.
UNLESS I HAVE GIVEN YOU EXPLICIT WRITTEN PERMISSION!

==Website==
www.flyingcarpet75.com

===Fltsim Entry===
---------------------------------------------------------------------------
add to aircraft.cfg (where x is the previous number +1)
---------------------------------------------------------------------------
[fltsim.X]
title=FAIB Boeing 737-400 Mid Africa Aviation
sim=FAIB_7374
model=logolight
texture=Fly Mid Africa
atc_airline=MID AFRICA
ui_manufacturer=FAIB
ui_type=Boeing 737-400
ui_variation=Fly Mid Africa
atc_parking_codes=MFG
atc_parking_types=GATE
description=FAIB 737-400 Mid Africa Aviation repaint by Robert Williams::FAIB::
----------------------------------------------------------------------------

Enjoy!
Robert Williams

robert-williams-fs9@hotmail.co.uk