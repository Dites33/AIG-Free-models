Texture into AZUL CONECTA FLEET liveries for HTAI C208B CARGOPOD
Repaint by Alexandre Alves with HD Paintkit by Morten Blindheim
=============================================================================
For install, unzip the texture.AZULCARGO, texture.AZULCONECTA, texture.AZULCONECTABRASIL, texture.AZULCONECTAROSA into your HTAI C208B CARGOPOD and ADD the lines bellow into your aircraft.cfg

[fltsim.x]
title=C208 AZUL CONECTA PT-MEM
sim=AI Cessna 208B
model=cp
panel=
sound=
texture=AZULCONECTA
ui_manufacturer=Cessna
ui_type=C208B
ui_variation="PT-MEM"
atc_heavy=0
atc_id=PT-MEM
atc_airline=TWOFLEX
atc_flight_number=
atc_parking_codes=OWT
atc_parking_types=RAMP
description=AI Cessna 208B Grand Caravan by Henry Tomkiewicz and Repainted by Alexandre Alves

[fltsim.x1]
title=C208 AZUL CONECTA PT-MED
sim=AI Cessna 208B
model=cp
panel=
sound=
texture=AZULCONECTAROSA
ui_manufacturer=Cessna
ui_type=C208B
ui_variation="PT-MED"
atc_heavy=0
atc_id=PT-MEM
atc_airline=TWOFLEX
atc_flight_number=
atc_parking_codes=OWT
atc_parking_types=RAMP
description=AI Cessna 208B Grand Caravan by Henry Tomkiewicz and Repainted by Alexandre Alves

[fltsim.x2]
title=C208 AZUL CONECTA PT-MEJ
sim=AI Cessna 208B
model=cp
panel=
sound=
texture=AZULCONECTABRASIL
ui_manufacturer=Cessna
ui_type=C208B
ui_variation="PT-MEJ"
atc_heavy=0
atc_id=PT-MEJ
atc_airline=TWOFLEX
atc_flight_number=
atc_parking_codes=OWT
atc_parking_types=RAMP
description=AI Cessna 208B Grand Caravan by Henry Tomkiewicz and Repainted by Alexandre Alves

[fltsim.x3]
title=C208 AZUL CARGO
sim=AI Cessna 208B
model=cp
panel=
sound=
texture=AZULCARGO
ui_manufacturer=Cessna
ui_type=C208B
ui_variation="PT-OZA"
atc_heavy=0
atc_id=PT-OZA
atc_airline=TWOFLEX
atc_flight_number=
atc_parking_codes=OWT
atc_parking_types=RAMP
description=AI Cessna 208B Grand Caravan by Henry Tomkiewicz and Repainted by Alexandre Alves

After this, insert on your AI TRAFFIC with personal flightplan and enjoy.
=============================================================================
Alexandre Alves
Brazil, November, 2020
islander_ktr@hotmail.com
=============================================================================
This month (November, 2020), I complete 20 years of flight simulation, there
are more than 200 files on FlightSim.com and 300 files on AVSIM, from scenary
to repaints, many many flight plans, after all AI TRAFFIC is mine passion!

If you like my work and want to send a "coffee" as a thank you, feel free at
paypal islander_ktr@hotmail.com. If you are Brazilian, contact me on the same
email if you want another way.

The giving in thanks is a free attitude of those who think it is cool to do.
=============================================================================