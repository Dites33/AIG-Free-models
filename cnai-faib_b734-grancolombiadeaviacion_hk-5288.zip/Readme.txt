Gran Colombia de Aviación (GCA Airlines) Boeing 737-400 repaint for the FSX AI Bureau (FAIB) AI model


THIS IS A FSX – P3Dv4 PAINT. 

These are only textures, tested on P3Dv4. The FAIB B734 base model is required. It can be found at https://fsxaibureau.com/

I have tried to make the repaint as close to the real aircraft as possible, using pictures on various sites on the internet.

To install these texture(s), copy the Texture.Gran Colombia de Aviacion HK-5288 folder into your FAIB B734 model folder.

Then, open your aircraft.cfg file and add the [fltsim.x] sections from the "fltsim.txt" file.
IMPORTANT:  Remember to change the "x" into the consecutive number.

This repaint is for AI traffic ONLY.

This file must NOT be used in any payware or freeware package.

The repaints are copyrighted to me, as the author, and must NOT be used in any freeware or payware package without my WRITTEN permission!



Repaint by Carlos Augusto Narváez Díaz
ca1972nd@hotmail.com
January 2020
