Bombardier Challenger 350 KCAI EFS European Flight Service EUW SE-RNR

Operator: EFS European Flight Service
Registration: SE-RNR
ICAO: EUW
Callsign: EUROWEST

Aircraft:
Repaints of C-GDIL, N255DV, N522AC, N272BC, SE-RNR for the Bombardier Challenger 350 AI model by Ken Carson.FS9 model available at https://www.alpha-india.net/forums/index.php?topic=29697.60FSX model available at https://www.alpha-india.net/forums/index.php?topic=29697.msg310551#msg310551

Flight plans:
https://oneclickhangar.com/forum/index.php



Please see separate file for aircraft.cfg configs

Legal
-----
These repaints have been downloaded from www.oneclickhangar.com
These repaints are copyright Morten Blindheim.
These repaints may not be uploaded to any other site.
If you have any comments or questions, please visit www.oneclickhangar.com or email at morten@oneclickhangar.com
Follow me on Twitter @oneclickhangar - https://twitter.com/oneclickhangar - for latest news on my FS add-ons 
