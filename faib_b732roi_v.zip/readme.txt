This textures for FSX AI BUREAU (FAIB) Boeing 737-200 (Normal and LogoLight) models, in Avior color variations. Two registrations included here.


Credits:  

Model & Paintkit:  Erez Werber
Paint: Ken Carson (nobodyxx_ad@yahoo.com)