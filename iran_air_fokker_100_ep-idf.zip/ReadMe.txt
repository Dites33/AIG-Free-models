This Readme based on files by AIG and TFS.

*******************************************************************************

DETAILS:

MODEL:		David Rawlins
WEBSITE:	www.ai-aardvark.com

REPAINT: 	Frank Drebing
EMAIL: 		drebing@live.de
WEBSITE: 	www.tagair.weebly.com / www.ai-flightpaints.weebly.com

AIRCRAFT:	Fokker 100
AIRLINE:	Iran Air
REGISTRATION:	EP-IDF
VARIATION:	-

*******************************************************************************

IMPORTANT LEGAL NOTICE:

This package and it's contents can't be redistributed in any way without the 
author's explicit and written permission.

*******************************************************************************

INSTALLATION INSTRUCTIONS:

1 - Just drop the "texture.iranair_EP-IDF" folder into the correct base model folder.
    (The base package must be downloaded separately to use this paint)

2 - Copy the [fltsim.x] entries from the aircraft.cfg into the aircraft.cfg of the base package.
    Make sure the entries are numeric. Start with [fltsim.0] and then number with
    [fltsim.1], [fltsim.2] etc.

3 - Then assign the aircraft to some flightplans and you're on your way.

*******************************************************************************

Made in Germany, 26 April 2019

*******************************************************************************