This is textures of Avior Airlines Boeing 737-400, for LogoLight model by FSX AI BUREAU (FAIB)

Credits:

Model and Paintkit:   Erez Werber
Paint:Ken Carson (nobodyxx_ad@yahoo.com)