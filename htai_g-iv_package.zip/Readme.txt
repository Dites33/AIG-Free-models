HTAI Gulfstream G-IV Mini Package

Thanks for downloading these repaints of the Gulfstream G-IV model by Henry Tomkiewicz.
Repaints and flightplans for 30 random G-IV's are included.

Note that this zip file only contains textures, you will need to download the base model (paintkit_gulfstream_g-iv_156494.zip) separately. The aircraft is intended to be used as AI traffic only.

-------

Installation:

Unzip this file into your HTAI Gulfstream G-IV folder in the aircraft folder of your FS9. Make sure you have "use folder names" checked. Add the contents of the separate "Add to aircraft.cfg" text file to the aircraft.cfg file and edit the [fltsim] section accordingly.

A list of the included aircraft and their bases can also be found in the archive. As just about all of these aircraft were included in the aging UltimateGA G-IV package, we have also included their old registrations (at the time of publishing of the UGA G-IV) in case you want to look up and remove the old ones.

One callsign mod to be imported using Editvoicepack is also included.

-------
LEGAL

This file and it's contents may not be uploaded anywhere without the author's permission. The textures may under no circumstances be sold. The textures may not be included in a package (free or not) without the author's written permission.
-------

Model and paintkit: Henry Tomkiewicz
Repaints: Daniel Fall
Flightplans: Alex Peake



Daniel Fall
danielfall@gmail.com
