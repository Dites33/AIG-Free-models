GENERAL

This repaint was created using the released paintkit for the model.

I have attempted to create a reasonable representation of the real aircraft based on Photos available on the internet,for my own use.

I am sharing these textures as a placeholder until a more skilled painter has time to create a more accurate version.

Flightplans for this aircraft are available on the internet with a little bit of searching.


LEGAL

Use these files entirely at your own risk.

This package requires a basic knowledge of inserting new textures into your flight simulator aircraft folders.

If you do not like them, simply remove them as you are accustomed.

These textures and files must remain freeware.  These files may not be uploaded to any other site by anyone else without the author's permission.

These textures have been tested on my system and appear to work.

These files should not harm your computer, but I will not accept responsibility for any negative outcome related to their installation, use or removal from your system.



CONTACT

John Tennent
tennentj@iafrica.com 