FSX AI Air Flamenco 2015 New Fleet Colors************************************************************************************

Information**********************************************************************************

 Air Flamenco is a Regional Airline from Puerto Rico that gives service to the Caribbean.They do schedule flights,charters
and cargo with their BN Islanders Fleet and a Shorts 360.They have been recently changing their Company and
Fleet colors.

 Here are their AI Air Flamenco 2015 New Fleet Colors Pack for FSX,FSX SE that includes:

-AI Models by HTAI (Henry Tomkiewicz),BN Islanders uses the long nose model.

-3 Repaints,2 BN Islanders and a Shorts 360 with their respective tail numbers and names.

-FSX-FSX Steam Props Textures by Tom Tiedman

-Xtra files for those who wishes to add something else to their models.

-Air Flamenco FP folder contains a set of fictional Flight Plans for this Models so you can have them flying around the
 Caribbean.

-Folder with Pictures(A YouTube video with the Xtra Files effects applied can be seen on the information bellow)

-Parking code for the BN Islanders is WAF

-Parking code for the Cargo Shorts 360 is WAFC

Installation************************************************************************************************

-Copy and paste the zip content in a temporary file or folder and just follow the order of the folders to install them.



********************************************************************************************************************

AI Models and paintkits from HTAI (Henry Tomkiewicz) here:

http://htai-models.com/downloads.html

Video of this project with more info,pics and a description of what AI Traffic is and what it does here:

http://youtu.be/RYuNMg4H0TI


**********************************************************************************************************************

Thank you for Downloading!!!!!


Questions or Comments are welcome!!!!

Preguntas o Comentarios son bienvenidos!!!!

God Bless you all!!!
Enjoy!!!!!!!!!!!!

Note: This material is freeware and should remain this way.Im not resposible for any problem that might cause to your 
       computer,so far no casualties but you install it at your own risk.

***********************************************************************************************************

Rafael "Fefi" Ortiz

 fefiaviationsim@yahoo.com


-Check my YouTube Channel for Flight simulator videos,Tutorials and upcoming projects-
 
 www.youtube.com/fefi747

-Now you can follow us on Social Media for updates,upcoming projects and more-

facebook
https://www.facebook.com/pages/Fefiaviationsim/820499478025052

twitter
https://twitter.com/Fefiaviationsim


MAR/2015
