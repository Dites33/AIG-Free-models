For FSX

//Air Flamenco is a schedule, charter and cargo airline based in San Juan Puerto Rico. It services Puerto Rico and adjacent islands of Culebra and Vieques. Also flies to the USA and British Virgin Islands and other parts of the Caribbean, including Dominican Republic.
They also appear to be operating out of Fort Lauderdale Executive Airport according to Flightradar24.com's flight history for aircraft N908GD.
//


//Textures for Air Flamenco's BN-2 and Shorts fleet for FSX.

These repaints are based on the work of Rafael Ortiz (Fefi), who has allowed me to use his textures to update the fleet and add new liveries to it. He's original Readme file is included. Big thanks to Rafael :) 

I am not an expert painter, but I hope these repaints are good enough for most FSX users.

As far as I understand, there are 9 BN-2 and 3 Shorts active in the Air Flamenco fleet presently. If any changes come up, I may do an update. 

N913GD is now assigned to a BN-2 since, and it is use for cargo. N913GD was a Shorts registration number but I am not aware as to why this was done. BN-2's wingtips were painted orange and tailfin art has been added to most of the fleet. N915GD did not need to be update so it is in its original paint, as created by Rafael Ortiz.

I've added Flight plans based on Flightradar24's and other websites. They are not 100% accurate but should provide an idea of the recent traffic.

//Installation

Place the textures in their corresponding ai model and copy the text in "add to aircraft cfg" readme to the corresponding aircraft.cfg file.
Remember to edit the [fltsim.xx] entry accordingly.

Place the Traffic_FG_WAF_2021.bgl file in the scenery/world/scenery folder

//

//Please note: 

This is freeware. 

These repaints are based on original paints from another painter who has allowed to make some changes. For any further editing, painting or distribution please ask him for permission.

Sorry, no support is offered for these textures. They should not cause any problem or harm your computer. 

You should have the proper ai model installed for each livery.
//

Enjoy!

Fred Guerra

11/20/2021
